package com.jarvis.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.media.MediaRecorder
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import java.io.File
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * Escucha continua con el reconocimiento de voz de Google y responde con la voz de Google (TTS).
 * Palabra de activación: "Hola Génesis". NUNCA habla sola: no saluda al arrancar y solo contesta cuando le dices "Hola Génesis"
 * seguido de la orden. Si dices solo "Hola Génesis", espera tu orden [CONVERSATION_MS]. Tras contestar, solo acepta un "gracias" suelto
 * durante unos segundos: responde "Es un placer servir." y se apaga por completo (igual que "sesión terminada").
 *
 * Micrófono persistente: un solo reconocedor reutilizado, pausas largas toleradas, reinicio casi inmediato,
 * perro guardián que lo revive si Android lo deja colgado y WakeLock para no dormirse con la pantalla apagada.
 *
 * Sesión: "sesión terminada" (o pulsación larga del botón) APAGA EL MICRÓFONO POR COMPLETO: destruye el reconocedor,
 * suelta el WakeLock y no habla. Para volver: tocar el botón del micrófono o el botón "Comenzar sesión" de la notificación;
 * responde "Sesión iniciada, sistemas listos". El estado se conserva al reiniciar el celular.
 *
 * No se contesta a sí misma: el micrófono se PAUSA mientras ella habla y se reabre ~0,9 s después de que termina
 * (así no capta su propia voz). Además descarta el eco de lo último que dijo.
 * Filtro de ruido: solo atiende si oye "Génesis" (o si dijiste solo su nombre hace unos segundos),
 * y descarta lo que el reconocedor marca con poca confianza (ruido, voz lejana, tele...).
 * Nota: Android no ofrece reconocimiento del hablante, así que no puede distinguir TU voz de otra; lo que hace es
 * ignorar todo lo que no empiece con la palabra de activación fuera de esa ventana.
 */
class JarvisService : Service(), RecognitionListener, TextToSpeech.OnInitListener {

    private val main = Handler(Looper.getMainLooper())
    private var rec: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private lateinit var brain: Brain
    private lateinit var engine: CommandEngine
    private var awakeUntil = 0L
    @Volatile private var speaking = false
    @Volatile private var paused = false          // true mientras se graba una canción (el micrófono no se comparte)
    @Volatile private var thinkSpoke = false
    @Volatile private var streamBusy = false      // la IA va diciendo frases mientras sigue escribiendo: el micrófono no se reabre entre frase y frase
    private var queuedChars = 0                   // texto encolado en la voz (para calcular la red de seguridad)
    private var lastSpoken = ""
    private var uid = 0
    private var lastUttId = ""
    @Volatile private var lastSpeechEnd = 0L
    @Volatile private var thanksUntil = 0L          // tras contestar, durante unos segundos acepta un "gracias" sin "Hola Génesis"
    @Volatile private var endAfterSpeech = false    // "gracias": cuando termine de decir "Es un placer servir." se apaga por completo
    private val clearSpeaking = Runnable { finishedSpeaking() }
    private val resumeListening = Runnable { if (!speaking) startListening() }
    @Volatile private var sessionOn = true
    private var pendingSpeak: String? = null      // lo que debía decir antes de que la voz estuviera lista
    private var lastActivity = 0L
    private var wakeLock: PowerManager.WakeLock? = null
    // ---- Fin de frase rápido: en cuanto dejas de hablar corta la escucha y ejecuta (sin esperar 3-4 s de silencio) ----
    @Volatile private var partialText = ""
    @Volatile private var partialAt = 0L
    @Volatile private var stopping = false
    @Volatile private var iaWarmed = false          // ya se precalentó la IA con lo que se está diciendo ahora
    @Volatile private var iaCheckLen = 0            // largo del texto la última vez que se revisó (para no revisar en cada sílaba)
    private val openEndRe = Regex("(?: a| de| del| que| y| e| o| con| en| el| la| los| las| un| una| para| por| diciendo| mi| tu| su| al)$")
    private val endCheck = object : Runnable {
        override fun run() {
            if (!stopping && !speaking && !paused && partialText.isNotBlank()) {
                val chat = IATalk.chatActive()
                val base = if (chat) END_CHAT_MS else END_CMD_MS
                val since = System.currentTimeMillis() - partialAt
                if (since >= base && (since >= base + OPEN_EXTRA_MS || !openEndRe.containsMatchIn(squash(partialText)))) {
                    stopping = true                      // terminó de hablar → cierra el micrófono y entrega lo oído ya mismo
                    try { rec?.stopListening() } catch (_: Exception) {}
                }
            }
            main.postDelayed(this, 80)
        }
    }

    private val watchdog = object : Runnable {
        override fun run() {
            IATalk.expiredNotice()?.let { speak(it) }       // la charla libre caducó por inactividad: avisa y vuelve al modo normal
            // Si el reconocedor lleva demasiado sin dar señales, se recrea desde cero.
            if (!paused && !speaking && System.currentTimeMillis() - lastActivity > 25_000) startListening(recreate = true)
            main.postDelayed(this, 5_000)
        }
    }

    private val wakeWords = listOf("genesis", "jenesis", "genesys", "yenesis")
    private val wakeStripRe = Regex("^(hola |oye |ok )?(genesis|jenesis|genesys|yenesis) ?")
    private val thanksRe = Regex("^(hola |oye |ok )?(genesis |jenesis )?(muchas |mil |muchisimas )?gracias( genesis| jenesis| por todo| por tu ayuda| por eso| de nuevo)?$")
    private val stopOnlyRe = Regex("^(hola |oye |ok )?(genesis |jenesis )?(para|detente|deten|basta|callate|silencio|espera|alto|cancela|ya)( ya| por favor)?$")
    // "sesión terminada", "terminar sesión", "termina la sesión", "cierra la sesión", "cerrar sesión", "fin de la sesión"
    private val endSessionRe = Regex("^(hola |oye |ok )?(genesis |jenesis )?(sesion terminada|(termina|terminar) (la )?sesion|(cierra|cerrar) (la )?sesion|fin de (la )?sesion)( por favor)?( genesis)?$")

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        sessionOn = Prefs.sessionOn(this)
        wakeLock = (getSystemService(POWER_SERVICE) as PowerManager)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "genesis:mic").apply { setReferenceCounted(false); if (sessionOn) acquire() }
        Extras.resume(this)
        brain = Brain(this); engine = CommandEngine(this, brain)
        engine.onThinking = { msg -> thinkSpoke = true; Hud.thinking(true); main.post { speak(msg) } }
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("jarvis", "Génesis", NotificationManager.IMPORTANCE_LOW))
        startForeground(1, notif(), android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        Bubble.sync(this)                                   // si la burbuja está activada, aparece (también tras reiniciar el celular)
        // Motor de voz de Google
        tts = TextToSpeech(this, this, "com.google.android.tts")
        lastActivity = System.currentTimeMillis()
        main.post { startListening() }
        main.postDelayed(watchdog, 5_000)
    }

    @Suppress("DEPRECATION")
    private fun notif(): Notification {
        val b = Notification.Builder(this, "jarvis")
            .setContentTitle(if (sessionOn) "Génesis activo" else "Génesis apagada (sesión terminada)")
            .setContentText(if (sessionOn) "Escuchando: di \"Hola Génesis\"" else "Micrófono apagado. Toca el botón para reactivarla")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).setOngoing(true)
        if (!sessionOn) {
            val pi = PendingIntent.getForegroundService(this, 1, Intent(this, JarvisService::class.java).setAction(ACTION_BEGIN),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            b.addAction(android.R.drawable.ic_btn_speak_now, "Comenzar sesión", pi)
        }
        val bi = PendingIntent.getForegroundService(this, 2, Intent(this, JarvisService::class.java).setAction(ACTION_BUBBLE),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        b.addAction(android.R.drawable.ic_menu_view, if (Prefs.bubbleOn(this)) "Quitar burbuja" else "Poner burbuja", bi)
        return b.build()
    }

    fun refreshNotif() { try { getSystemService(NotificationManager::class.java).notify(1, notif()) } catch (_: Exception) {} }

    fun beginSession() {
        sessionOn = true; Prefs.setSessionOn(this, true)
        try { wakeLock?.let { if (!it.isHeld) it.acquire() } } catch (_: Exception) {}
        lastActivity = System.currentTimeMillis()
        main.removeCallbacks(watchdog); main.postDelayed(watchdog, 5_000)
        getSystemService(NotificationManager::class.java).notify(1, notif()); Bubble.sync(this)
        awakeUntil = System.currentTimeMillis() + CONVERSATION_MS
        startListening(recreate = true)                    // vuelve a abrir el micrófono
        speak("Sesión iniciada, sistemas listos", force = true)
    }

    fun endSession() {
        engine.stopAutoClick()
        stopSpeaking()
        sessionOn = false; Prefs.setSessionOn(this, false)
        if (IATalk.chatOn) IATalk.endChat(this)
        main.removeCallbacks(endCheck)
        awakeUntil = 0L
        main.removeCallbacks(watchdog)
        // MICRÓFONO APAGADO POR COMPLETO: se destruye el reconocedor y se suelta el WakeLock
        try { rec?.cancel(); rec?.destroy() } catch (_: Exception) {}
        rec = null
        Quiet.release()
        try { wakeLock?.let { if (it.isHeld) it.release() } } catch (_: Exception) {}
        Hud.listening(false); Hud.thinking(false)
        getSystemService(NotificationManager::class.java).notify(1, notif()); Bubble.sync(this)
    }

    override fun onInit(status: Int) {
        if (status != TextToSpeech.SUCCESS) return
        ttsReady = true
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            // Solo cuenta el último mensaje encolado: así el micrófono no se reabre entre "déjame pensar…" y la respuesta
            override fun onStart(id: String?) { main.post { if (id == lastUttId) speaking = true } }
            override fun onDone(id: String?) { main.post { if (id == lastUttId) finishedSpeaking() } }
            @Deprecated("Deprecated in Java") override fun onError(id: String?) { main.post { if (id == lastUttId) finishedSpeaking() } }
            override fun onStop(id: String?, interrupted: Boolean) { main.post { if (id == lastUttId) finishedSpeaking() } }
        })
        applyVoice()
        val p = pendingSpeak; pendingSpeak = null
        if (p != null) speak(p, force = true)          // sin saludo de arranque: no habla hasta que le digas "Hola Génesis"
    }

    fun applyVoice() {
        val t = tts ?: return
        t.language = Locale("es", "ES")
        t.setPitch(Prefs.pitch(this))
        Prefs.voice(this)?.let { name -> t.voices?.firstOrNull { it.name == name }?.let { v: Voice -> t.voice = v } }
    }

    fun voices(): List<Voice> = tts?.voices?.filter { it.locale.language == "es" }?.sortedBy { it.name } ?: emptyList()

    fun isSpeaking() = speaking

    /** [add] = true encola detrás de lo que ya está diciendo (p. ej. tras "déjame pensar…"). */
    fun speak(text: String, add: Boolean = false, force: Boolean = false) {
        if (!sessionOn && !force) return          // sesión terminada: no habla (recordatorios, notificaciones, etc.)
        Quiet.release()                           // su voz nunca debe quedar silenciada por el filtro del bip
        Hud.say(text)
        lastSpoken = if (add) "$lastSpoken $text" else text
        if (!ttsReady) { pendingSpeak = text; return }
        speaking = true
        main.removeCallbacks(resumeListening)
        main.removeCallbacks(endCheck)
        try { rec?.cancel() } catch (_: Exception) {}           // mientras habla, el micrófono se pausa
        Hud.listening(false)
        uid++
        lastUttId = "j$uid"
        tts?.speak(text, if (add) TextToSpeech.QUEUE_ADD else TextToSpeech.QUEUE_FLUSH, null, lastUttId)
        // red de seguridad por si Android nunca avisa que terminó
        main.removeCallbacks(clearSpeaking)
        queuedChars = if (add) queuedChars + text.length else text.length
        main.postDelayed(clearSpeaking, queuedChars * 90L + 2500L)
    }

    fun stopSpeaking() { tts?.stop(); finishedSpeaking() }

    fun isSessionOn() = sessionOn

    /** Para la barra de comandos escrita: ejecuta el texto como si lo hubieras dicho. Se llama desde un hilo de fondo. */
    fun runText(text: String): String = engine.handle(text)

    /** Terminó de hablar: reabre el micrófono tras una pequeña cola de silencio (para no oír el final de su propia voz). */
    private fun finishedSpeaking() {
        speaking = false
        lastSpeechEnd = System.currentTimeMillis()
        lastActivity = lastSpeechEnd
        thanksUntil = lastSpeechEnd + 8_000L
        main.removeCallbacks(clearSpeaking)
        main.removeCallbacks(resumeListening)
        if (endAfterSpeech) { endAfterSpeech = false; endSession(); return }   // "gracias": terminó de despedirse → se apaga
        queuedChars = 0
        if (!streamBusy) main.postDelayed(resumeListening, if (IATalk.chatActive()) TAIL_CHAT_MS else TAIL_MS)
    }

    /** Mantiene a Génesis escuchando órdenes sin la palabra de activación durante unos segundos. */
    fun wakeFor(ms: Long) { awakeUntil = maxOf(awakeUntil, System.currentTimeMillis() + ms) }

    private fun online(): Boolean {
        val cm = getSystemService(ConnectivityManager::class.java)
        val c = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
        return c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    private fun hasWake(n: String) = wakeWords.any { n.contains(it) }
    /** ¿Lo que "oí" es en realidad ella misma hablando por el altavoz? */
    private fun squash(s: String) = Brain.norm(s).replace(Regex("[^a-z0-9 ]"), " ").replace(Regex("\\s+"), " ").trim()
    private fun isEcho(clean: String) = clean.isNotEmpty() && squash(lastSpoken).contains(clean)

    private fun startListening(recreate: Boolean = false) {
        if (paused || !sessionOn || speaking || !SpeechRecognizer.isRecognitionAvailable(this)) return
        lastActivity = System.currentTimeMillis()
        try {
            if (recreate || rec == null) {
                rec?.destroy()
                rec = SpeechRecognizer.createSpeechRecognizer(this).also { it.setRecognitionListener(this) }
            } else {
                rec?.cancel()
            }
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-ES")
                .putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
                .putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, !online())
                // Rápido: texto parcial en vivo y silencios cortos (el corte fino lo hace [endCheck], que además espera si la frase quedó a medias)
                .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                .putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1400L)
                .putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1100L)
                .putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 400L)
            Quiet.hush(this)                                // sin el "bip" de Google al abrir el micrófono
            partialText = ""; partialAt = 0L; stopping = false; iaWarmed = false; iaCheckLen = 0
            main.removeCallbacks(endCheck); main.postDelayed(endCheck, 80)
            rec?.startListening(i)
        } catch (e: Exception) {
            rec = null
            restart(1500)
        }
    }

    private fun restart(delay: Long = 150, recreate: Boolean = false) {
        if (!paused) main.postDelayed({ startListening(recreate) }, delay)
    }

    override fun onPartialResults(p: Bundle?) {
        val t = p?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: return
        lastActivity = System.currentTimeMillis()
        if (t != partialText) {
            partialText = t; partialAt = lastActivity
            // En pantalla solo lo que va dirigido a ella (así no muestra charla ajena)
            val toMe = hasWake(Brain.norm(t)) || lastActivity < awakeUntil || IATalk.chatActive()
            if (toMe) Hud.heard(t)
            // Si lo que dices parece una orden para su IA, la enciende YA (mientras terminas de hablar) para contestar sin esperar la carga
            if (toMe && !iaWarmed && t.length >= 6 && t.length >= iaCheckLen + 6) {
                iaCheckLen = t.length
                val heard = t
                Thread { if (IATalk.wantsIA(heard)) { iaWarmed = true; IA.warm(applicationContext) } }.start()
            }
        }
    }

    override fun onResults(r: Bundle?) {
        Quiet.hush(this)
        lastActivity = System.currentTimeMillis()
        val said = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
        val conf = r?.getFloatArray(SpeechRecognizer.CONFIDENCE_SCORES)?.firstOrNull() ?: -1f
        main.removeCallbacks(endCheck)
        val accepted = said != null && !paused && handleSaid(said, conf)
        if (!accepted) restart()                       // si atendió la orden, el micrófono se queda cerrado hasta que termine de contestar
    }

    /** Devuelve true si atendió la frase (entonces el micrófono espera a que termine de contestar). */
    private fun handleSaid(said: String, conf: Float): Boolean {
        val n = Brain.norm(said)
        val clean = squash(said)                       // sin signos: "Cierra la sesión." → "cierra la sesion"
        val now = System.currentTimeMillis()

        if (!sessionOn) return false                   // sesión terminada: el micrófono está apagado
        if (endSessionRe.matches(clean)) { endSession(); return true }

        if (speaking) return false                     // mientras habla no atiende nada (era su propia voz)
        if (clean.length >= 3 && now - lastSpeechEnd < 6000 && isEcho(clean)) return false   // cola de su propia voz
        val chat = IATalk.chatActive()                 // charla libre ("usa tu IA"): no hace falta decir "Hola Génesis"
        val wake = hasWake(n)
        val thanks = thanksRe.matches(clean)
        if (!wake && !chat && now >= awakeUntil && !(thanks && now < thanksUntil)) return false   // ruido o charla ajena: ni caso
        // Poca confianza = probablemente ruido, voz lejana o tele (la confianza 0 o -1 significa "no disponible")
        if (conf > 0f && conf < (if (wake) 0.3f else if (chat) 0.4f else 0.6f)) return false

        if (stopOnlyRe.matches(n)) {
            // "para", "espera", "silencio"…: detiene el clic automático si estaba activo
            if (engine.stopAutoClick()) { speak("Clic automático detenido."); return true }
            return false
        }
        if (thanks && !chat) {                         // "gracias" → "Es un placer servir." y se apaga por completo
            awakeUntil = 0L; Hud.heard(said); engine.stopAutoClick()
            endAfterSpeech = true
            speak("Es un placer servir.")
            return true
        }
        // Sin "chat abierto": cada orden necesita "Hola Génesis". Solo si dijiste únicamente su nombre, espera tu orden unos segundos.
        awakeUntil = if (wake && clean.replace(wakeStripRe, "").isEmpty()) now + CONVERSATION_MS else 0L
        Hud.heard(said)
        Hud.thinking(true)
        Thread {
            thinkSpoke = false
            // Si la IA contesta, va diciendo cada frase en cuanto la escribe (sin esperar la respuesta completa)
            IA.sink = { sentence -> streamBusy = true; thinkSpoke = true; main.post { speak(sentence, true) } }
            val reply = try { engine.handle(said) } catch (e: Exception) { "Algo salió mal." } finally { IA.sink = null; streamBusy = false }
            Hud.thinking(false)
            // La ventana de conversación se renueva cuando ella termina de contestar
            main.post { if (reply.isBlank()) restart() else speak(reply, thinkSpoke) }
        }.start()
        return true
    }

    override fun onError(error: Int) {
        Quiet.hush(this)                                  // el tono de error tampoco debe sonar
        main.removeCallbacks(endCheck)
        lastActivity = System.currentTimeMillis()
        when (error) {
            // Silencio o nada reconocido: lo normal en escucha continua → reinicio casi inmediato, sin recrear
            SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> restart(100)
            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> {}   // sin permiso de micrófono no tiene sentido reintentar en bucle
            SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> restart(1500, recreate = true)
            else -> restart(600, recreate = true)                    // cliente, red, servidor, demasiadas peticiones…
        }
    }
    override fun onReadyForSpeech(p: Bundle?) { lastActivity = System.currentTimeMillis(); Hud.listening(true) }
    override fun onEndOfSpeech() { Quiet.hush(this); Hud.listening(false) }       // y sin el bip al cerrarlo
    override fun onBeginningOfSpeech() { lastActivity = System.currentTimeMillis() }
    override fun onRmsChanged(v: Float) { lastActivity = System.currentTimeMillis(); Hud.level(v) }
    override fun onBufferReceived(b: ByteArray?) {}
    override fun onEvent(t: Int, p: Bundle?) {}

    /**
     * Graba [ms] milisegundos del micrófono (para reconocer una canción). Pausa el reconocimiento de voz,
     * porque Android no deja que dos apps usen el micrófono a la vez. Se llama desde un hilo de fondo.
     */
    @Suppress("DEPRECATION")
    fun recordClip(ms: Long): File? {
        paused = true
        val latch = CountDownLatch(1)
        main.post { try { rec?.destroy() } catch (_: Exception) {}; rec = null; latch.countDown() }
        latch.await(2, TimeUnit.SECONDS)
        Thread.sleep(400)
        val f = File(cacheDir, "cancion.m4a")
        var mr: MediaRecorder? = null
        return try {
            mr = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else MediaRecorder()
            mr.setAudioSource(MediaRecorder.AudioSource.MIC)
            mr.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            mr.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            mr.setAudioSamplingRate(44100); mr.setAudioEncodingBitRate(128000)
            mr.setOutputFile(f.path)
            mr.prepare(); mr.start()
            Thread.sleep(ms)
            mr.stop()
            f
        } catch (e: Exception) { null }
        finally {
            try { mr?.release() } catch (_: Exception) {}
            paused = false
            main.post { startListening() }
        }
    }

    override fun onStartCommand(i: Intent?, f: Int, s: Int): Int {
        if (i?.action == ACTION_BEGIN) main.post { beginSession() }      // botón del micrófono con el servicio apagado
        if (i?.action == ACTION_BUBBLE) main.post { Bubble.toggle(this) } // botón de la notificación: poner o quitar la burbuja
        return START_STICKY
    }

    override fun onDestroy() {
        instance = null
        main.removeCallbacks(watchdog)
        Quiet.release()
        try { rec?.destroy() } catch (_: Exception) {}
        tts?.shutdown()
        try { wakeLock?.release() } catch (_: Exception) {}
        super.onDestroy()
    }

    companion object {
        var instance: JarvisService? = null
        /** Si dices solo "Hola Génesis" (o tocas el micrófono), cuánto espera tu orden sin que repitas su nombre. */
        const val CONVERSATION_MS = 8_000L
        private const val TAIL_MS = 350L              // cola de silencio tras hablar antes de reabrir el micrófono (el eco se filtra por texto)
        private const val TAIL_CHAT_MS = 450L
        private const val END_CMD_MS = 650L           // silencio tras una orden → se da por terminada
        private const val END_CHAT_MS = 900L          // en charla libre espera un poco más (frases más largas)
        private const val OPEN_EXTRA_MS = 600L        // si la frase quedó a medias ("manda mensaje a…"), espera este extra
        const val ACTION_BEGIN = "com.jarvis.assistant.BEGIN_SESSION"
        const val ACTION_BUBBLE = "com.jarvis.assistant.TOGGLE_BUBBLE"

        /** Botón del micrófono: equivale a decir "comenzar sesión" (arranca el servicio si estaba apagado). */
        fun begin(c: android.content.Context) {
            val s = instance
            if (s != null) { if (s.isSessionOn()) s.stopSpeaking() else s.beginSession() }   // sesión ya activa: el botón solo la calla
            else androidx.core.content.ContextCompat.startForegroundService(c, Intent(c, JarvisService::class.java).setAction(ACTION_BEGIN))
        }

        /** Pulsación larga del botón: equivale a decir "sesión terminada". */
        fun end() { instance?.endSession() }
    }
}

/** Estado compartido para animar el HUD. */
object Hud {
    var listener: (() -> Unit)? = null
    @Volatile var rms = 0f; @Volatile var isListening = false
    @Volatile var thinking = false
    @Volatile var lastHeard = ""; @Volatile var lastSaid = ""
    fun level(v: Float) { rms = v; listener?.invoke() }
    fun listening(b: Boolean) { isListening = b; listener?.invoke() }
    fun thinking(b: Boolean) { thinking = b; listener?.invoke() }
    fun heard(s: String) { lastHeard = s; listener?.invoke() }
    fun say(s: String) { lastSaid = s; listener?.invoke() }
}
