package com.jarvis.assistant

import android.content.Context
import androidx.work.Constraints
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * APRENDIZAJE AUTOMÁTICO MASIVO (botón "Aprender" del menú, o "aprende de todo").
 *
 * En segundo plano y sin que hagas nada, Génesis lee artículos COMPLETOS de Wikipedia en español (no solo el resumen),
 * los trocea y los guarda en su cerebro (SQLite, Mind.kb). Se alimenta de:
 *   1) las preguntas que no supo contestar,
 *   2) temas semilla de todas las áreas (cientos),
 *   3) los enlaces de cada artículo que lee (crece como una telaraña),
 *   4) artículos al azar, para que no haya tema que se le escape.
 * También arranca el diccionario completo (Wiktionario).
 * Por defecto solo usa Wi-Fi (para no gastar tus datos) y se pausa con batería baja o poco espacio libre.
 * Android decide cuándo ejecutarlo: sigue aunque cierres la app.
 */
object Turbo {
    private const val WORK = "genesis-turbo"
    private const val UA = "GenesisAssistant/1.5 (asistente personal Android; aprendizaje)"
    private const val FRONTIER = "turbo_frontier.txt"

    private val extraSeeds = listOf(
        // ciencias
        "Mecánica cuántica", "Relatividad", "Termodinámica", "Óptica", "Magnetismo", "Gravedad", "Tabla periódica", "Molécula",
        "Ácido", "Reacción química", "Química orgánica", "Bioquímica", "ADN", "ARN", "Proteína", "Virus", "Bacteria", "Hongo",
        "Ecología", "Ecosistema", "Cambio climático", "Geología", "Volcán", "Terremoto", "Meteorología", "Huracán", "Agua",
        "Oxígeno", "Carbono", "Hierro", "Oro", "Petróleo", "Energía solar", "Energía nuclear", "Agujero negro", "Galaxia",
        "Vía Láctea", "Luna", "Marte", "Sol", "Estrella", "Cometa", "Exploración espacial", "Dinosaurio", "Fósil",
        // tecnología
        "Algoritmo", "Estructura de datos", "Base de datos", "Sistema operativo", "Linux", "Red informática", "Criptografía",
        "Cadena de bloques", "Bitcoin", "Computación en la nube", "Python", "Kotlin", "JavaScript", "HTML", "Red neuronal artificial",
        "Realidad virtual", "Impresión 3D", "Energía renovable", "Automóvil eléctrico", "Avión", "Tren", "Satélite artificial",
        "Telecomunicación", "Radio", "Televisión", "Batería eléctrica", "Semiconductor", "Microprocesador",
        // salud
        "Corazón", "Cerebro humano", "Sistema inmunitario", "Diabetes", "Hipertensión arterial", "Cáncer", "Alergia", "Dolor",
        "Fiebre", "Antibiótico", "Higiene", "Salud mental", "Depresión", "Meditación", "Yoga", "Obesidad", "Lactancia materna",
        "Pediatría", "Odontología", "Farmacia",
        // humanidades, historia y sociedad
        "Sociología", "Antropología", "Arqueología", "Lingüística", "Retórica", "Ética", "Epistemología", "Estoicismo",
        "Cristianismo", "Islam", "Budismo", "Judaísmo", "Imperio romano", "Antigua Grecia", "Imperio azteca", "Imperio inca",
        "Cristóbal Colón", "Revolución industrial", "Napoleón Bonaparte", "Simón Bolívar", "Juan Pablo Duarte", "Revolución rusa",
        "Organización de las Naciones Unidas", "Unión Europea", "Democracia", "Constitución", "Derechos humanos",
        // economía y trabajo
        "Comercio", "Mercado", "Oferta y demanda", "Banco", "Dinero", "Producto interno bruto", "Desempleo", "Globalización",
        "Mercadotecnia", "Administración de empresas", "Liderazgo", "Negociación", "Productividad", "Gestión del tiempo",
        // geografía
        "Brasil", "Chile", "Perú", "Venezuela", "Cuba", "Puerto Rico", "Haití", "Francia", "Alemania", "Italia", "Reino Unido",
        "Rusia", "India", "Corea del Sur", "Egipto", "Nigeria", "Australia", "Canadá", "Santo Domingo", "Madrid", "Nueva York",
        "Mar Caribe", "Amazonas", "Andes", "Desierto", "Isla", "Continente",
        // arte, deporte y cultura
        "Arquitectura", "Escultura", "Literatura hispanoamericana", "Don Quijote de la Mancha", "Gabriel García Márquez", "Teatro",
        "Ópera", "Jazz", "Rock", "Hip hop", "Fútbol americano", "Tenis", "Voleibol", "Ajedrez", "Juegos Olímpicos",
        "Copa Mundial de Fútbol", "Historieta", "Animación", "Periodismo", "Moda", "Diseño", "Jardinería", "Agricultura",
        "Ganadería", "Pesca", "Minería", "Construcción", "Carpintería",
        // comida
        "Gastronomía de la República Dominicana", "Gastronomía de México", "Gastronomía de Italia", "Gastronomía de China", "Sushi",
        "Vino", "Cerveza", "Ron", "Azúcar", "Sal", "Aceite de oliva", "Huevo", "Leche", "Yogur", "Frijol", "Maíz", "Plátano",
        "Mango", "Aguacate", "Coco", "Tomate", "Papa", "Cebolla", "Ajo"
    )

    fun running(c: Context) = Prefs.turboOn(c)

    private fun constraints(c: Context) = Constraints.Builder()
        .setRequiredNetworkType(if (Prefs.turboWifi(c)) NetworkType.UNMETERED else NetworkType.CONNECTED)
        .setRequiresBatteryNotLow(true).build()

    private fun enqueue(c: Context, delayMin: Long, policy: ExistingWorkPolicy) {
        val req = OneTimeWorkRequestBuilder<TurboWorker>()
            .setConstraints(constraints(c)).setInitialDelay(delayMin, TimeUnit.MINUTES).build()
        WorkManager.getInstance(c.applicationContext).enqueueUniqueWork(WORK, policy, req)
    }

    fun start(c: Context) {
        Prefs.setTurboOn(c, true)
        enqueue(c, 0, ExistingWorkPolicy.REPLACE)
        Vocab.start(c)                                   // y el diccionario completo
    }

    fun stop(c: Context) {
        Prefs.setTurboOn(c, false)
        WorkManager.getInstance(c.applicationContext).cancelUniqueWork(WORK)
        Vocab.stop(c)
    }

    fun setWifiOnly(c: Context, v: Boolean) {
        Prefs.setTurboWifi(c, v)
        if (Prefs.turboOn(c)) enqueue(c, 0, ExistingWorkPolicy.REPLACE)    // reprograma con la nueva condición de red
    }

    class TurboWorker(c: Context, p: WorkerParameters) : Worker(c, p) {
        override fun doWork(): Result {
            val c = applicationContext
            try { if (Prefs.turboOn(c)) batch(c) { isStopped } } catch (_: Exception) {}
            if (Prefs.turboOn(c)) enqueue(c, 1, ExistingWorkPolicy.APPEND_OR_REPLACE)
            return Result.success()
        }
    }

    /** Una tanda de hasta 8 minutos (Android corta los trabajos largos). */
    private fun batch(c: Context, stopped: () -> Boolean) {
        val frontier = readList(c, FRONTIER).toMutableList()
        if (frontier.isEmpty()) frontier.addAll((AutoLearner.seeds + extraSeeds).shuffled())
        val pending = AutoLearner.takePending(c).toMutableList()
        val end = System.currentTimeMillis() + 8 * 60 * 1000L
        var fails = 0; var rounds = 0
        while (System.currentTimeMillis() < end && Prefs.turboOn(c) && !stopped()) {
            if (CloudArchive.critical(c)) break                       // poco espacio libre: se pausa
            rounds++
            val title: String? = when {
                pending.isNotEmpty() -> search(clean(pending.removeAt(0)))
                rounds % 4 == 0 || frontier.isEmpty() -> randomTitle()   // 1 de cada 4: algo al azar, para abarcar de todo
                else -> frontier.removeAt(0)
            }
            if (title == null) { if (++fails >= 8) break; Thread.sleep(1500); continue }
            if (title.contains(":") || Mind.hasTopic(c, title)) continue
            val art = article(title)
            if (art == null) { if (++fails >= 8) break; Thread.sleep(800); continue }
            fails = 0
            val parts = chunks(art.text)
            if (Mind.learn(c, art.title, parts) > 0) { Prefs.addTurboArticles(c, 1); CodeLab.fromFact(c, art.title, parts.firstOrNull().orEmpty()) }
            for (l in art.links.shuffled().take(10)) if (!l.contains(":") && !Mind.hasTopic(c, l) && l !in frontier) frontier.add(l)
            if (frontier.size > 3000) { val keep = frontier.shuffled().take(2000); frontier.clear(); frontier.addAll(keep) }
            Thread.sleep(400)                                         // cortesía con los servidores de Wikipedia
        }
        writeList(c, FRONTIER, frontier.distinct().take(3000))
    }

    private class Art(val title: String, val text: String, val links: List<String>)

    private fun clean(q: String) = Brain.norm(q)
        .replace(Regex("^(que es|que son|quien es|quien fue|que significa|explicame|dime sobre|como funciona) "), "")

    private fun search(q: String): String? {
        val r = Web.fetch("https://es.wikipedia.org/w/api.php?action=opensearch&limit=1&format=json&search=" + Net.enc(q), 10000, UA) ?: return null
        return try { JSONArray(r).getJSONArray(1).optString(0).ifBlank { null } } catch (_: Exception) { null }
    }

    private fun randomTitle(): String? {
        val r = Web.fetch("https://es.wikipedia.org/w/api.php?action=query&list=random&rnnamespace=0&rnlimit=1&format=json", 10000, UA) ?: return null
        return try { JSONObject(r).getJSONObject("query").getJSONArray("random").getJSONObject(0).getString("title") } catch (_: Exception) { null }
    }

    /** Artículo completo (texto plano) y hasta 60 enlaces a otros artículos. */
    private fun article(t: String): Art? {
        val r = Web.fetch(
            "https://es.wikipedia.org/w/api.php?action=query&prop=extracts%7Clinks&explaintext=1&exsectionformat=plain&redirects=1" +
                "&plnamespace=0&pllimit=60&format=json&titles=" + Net.enc(t), 15000, UA, 1_500_000) ?: return null
        return try {
            val pages = JSONObject(r).getJSONObject("query").getJSONObject("pages")
            val p = pages.getJSONObject(pages.keys().next())
            if (p.has("missing")) return null
            val text = p.optString("extract")
            if (text.length < 200 || text.take(300).contains("puede referirse a")) return null      // vacío o desambiguación
            val links = ArrayList<String>()
            p.optJSONArray("links")?.let { a -> for (i in 0 until a.length()) links.add(a.getJSONObject(i).getString("title")) }
            Art(p.optString("title", t), text, links)
        } catch (_: Exception) { null }
    }

    /** Trocea el artículo en fragmentos de ~500-900 caracteres (hasta 14), cortando en frases. */
    private fun chunks(text: String): List<String> {
        val out = ArrayList<String>(); val cur = StringBuilder()
        for (line in text.lines().map { it.trim() }.filter { it.length > 1 }) {
            if (cur.isNotEmpty()) cur.append(' ')
            cur.append(line)
            if (cur.length >= 500) { out.add(Net.sentences(cur.toString(), 900)); cur.clear() }
            if (out.size >= 14) break
        }
        if (cur.length > 120 && out.size < 14) out.add(Net.sentences(cur.toString(), 900))
        return out
    }

    private fun readList(c: Context, f: String): List<String> {
        val file = c.getFileStreamPath(f); return if (file.exists()) file.readLines().filter { it.isNotBlank() } else emptyList()
    }
    private fun writeList(c: Context, f: String, l: Collection<String>) { c.getFileStreamPath(f).writeText(l.joinToString("\n")) }
}
