package com.jarvis.assistant

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.min
import kotlin.math.sin

/** Sonidos futuristas generados por código (sin archivos de audio). */
object Sfx {
    private const val SR = 22050

    private fun synth(seconds: Double, f: (Double) -> Double): ShortArray {
        val n = (SR * seconds).toInt()
        val out = ShortArray(n)
        var peak = 0.0001
        val tmp = DoubleArray(n) { f(it.toDouble() / SR).also { v -> if (kotlin.math.abs(v) > peak) peak = kotlin.math.abs(v) } }
        for (i in 0 until n) out[i] = (tmp[i] / peak * 0.7 * Short.MAX_VALUE).toInt().toShort()
        return out
    }

    private fun play(data: ShortArray) {
        Thread {
            try {
                val t = AudioTrack.Builder()
                    .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
                    .setAudioFormat(AudioFormat.Builder().setSampleRate(SR)
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                    .setBufferSizeInBytes(data.size * 2).setTransferMode(AudioTrack.MODE_STATIC).build()
                t.write(data, 0, data.size); t.play()
                Thread.sleep(data.size * 1000L / SR + 200); t.release()
            } catch (_: Exception) {}
        }.start()
    }

    private fun chirp(t: Double, f0: Double, f1: Double, dur: Double) =
        sin(2 * PI * (f0 * t + (f1 - f0) / (2 * dur) * t * t))

    /** Arranque: barrido ascendente, pitidos de datos y acorde final. */
    fun boot() = play(synth(4.0) { t ->
        val sweep = chirp(t, 70.0, 900.0, 3.2) * min(t / 0.4, 1.0) * (if (t < 3.2) 0.55 else 0.0) *
                (0.75 + 0.25 * sin(2 * PI * 9 * t))
        val rumble = sin(2 * PI * 48 * t) * exp(-t * 0.6) * 0.5
        var blips = 0.0
        for (k in listOf(0.6, 1.1, 1.6, 2.1, 2.6)) {
            val d = t - k
            if (d in 0.0..0.09) blips += sin(2 * PI * (1500 + k * 300) * d) * (1 - d / 0.09) * 0.45
        }
        val c = t - 3.0
        val chord = if (c >= 0) (sin(2 * PI * 440 * c) + sin(2 * PI * 660 * c) + sin(2 * PI * 880 * c) + 0.6 * sin(2 * PI * 1320 * c)) *
                exp(-c * 3.2) * 0.35 else 0.0
        sweep + rumble + blips + chord
    })

    fun tap() = play(synth(0.14) { t -> chirp(t, 900.0, 1900.0, 0.14) * (1 - t / 0.14) })
    fun menuOpen() = play(synth(0.45) { t -> chirp(t, 250.0, 1400.0, 0.45) * sin(PI * t / 0.45) * 0.8 + 0.2 * sin(2 * PI * 80 * t) * (1 - t / 0.45) })
    fun select() = play(synth(0.18) { t ->
        (sin(2 * PI * 1200 * t) + 0.5 * sin(2 * PI * 1800 * t)) * exp(-t * 18)
    })
    fun ready() = play(synth(0.5) { t ->
        (sin(2 * PI * 660 * t) * (if (t < 0.12) 1.0 else 0.0) + sin(2 * PI * 990 * (t - 0.12)) * (if (t >= 0.12) exp(-(t - 0.12) * 7) else 0.0))
    })
}
