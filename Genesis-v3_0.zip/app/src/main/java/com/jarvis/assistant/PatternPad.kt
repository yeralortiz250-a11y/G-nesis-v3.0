package com.jarvis.assistant

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.hypot

/**
 * Cuadrícula de 9 puntos para dibujar (y así guardar) tu patrón de desbloqueo.
 * Los puntos se numeran por filas: 1 2 3 / 4 5 6 / 7 8 9. Igual que Android, si pasas por encima de un punto
 * intermedio que no habías marcado (de 1 a 3 pasas por el 2), se marca solo.
 */
class PatternPad(c: Context) : View(c) {
    val seq = ArrayList<Int>()
    var onChange: (() -> Unit)? = null
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var fx = -1f; private var fy = -1f

    private fun cx(d: Int) = width * ((d - 1) % 3 + 0.5f) / 3f
    private fun cy(d: Int) = height * ((d - 1) / 3 + 0.5f) / 3f

    fun clear() { seq.clear(); fx = -1f; fy = -1f; invalidate(); onChange?.invoke() }

    private fun add(d: Int) {
        if (d in seq) return
        if (seq.isNotEmpty()) {
            val l = seq.last()
            val r1 = (l - 1) / 3; val c1 = (l - 1) % 3; val r2 = (d - 1) / 3; val c2 = (d - 1) % 3
            val dr = abs(r1 - r2); val dc = abs(c1 - c2)
            if (dr % 2 == 0 && dc % 2 == 0 && (dr == 2 || dc == 2)) {          // hay un punto en medio en línea recta
                val mid = ((r1 + r2) / 2) * 3 + (c1 + c2) / 2 + 1
                if (mid !in seq) seq.add(mid)
            }
        }
        seq.add(d)
    }

    private fun hit(x: Float, y: Float) {
        for (d in 1..9) if (hypot(x - cx(d), y - cy(d)) < width / 3f * 0.32f) { add(d); return }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { parent?.requestDisallowInterceptTouchEvent(true); seq.clear(); fx = e.x; fy = e.y; hit(e.x, e.y) }
            MotionEvent.ACTION_MOVE -> { fx = e.x; fy = e.y; hit(e.x, e.y) }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { fx = -1f; fy = -1f }
        }
        invalidate(); onChange?.invoke()
        return true
    }

    override fun onDraw(cv: Canvas) {
        val col = Prefs.color(context)
        p.style = Paint.Style.STROKE; p.strokeWidth = 10f; p.strokeCap = Paint.Cap.ROUND; p.color = col
        for (i in 1 until seq.size) cv.drawLine(cx(seq[i - 1]), cy(seq[i - 1]), cx(seq[i]), cy(seq[i]), p)
        if (fx >= 0 && seq.isNotEmpty()) cv.drawLine(cx(seq.last()), cy(seq.last()), fx, fy, p)
        p.style = Paint.Style.FILL
        for (d in 1..9) {
            val on = d in seq
            p.color = if (on) col else Color.GRAY
            cv.drawCircle(cx(d), cy(d), if (on) 20f else 12f, p)
        }
    }
}
