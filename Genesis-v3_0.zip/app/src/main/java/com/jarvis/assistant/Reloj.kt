package com.jarvis.assistant

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.AlarmClock
import java.text.Normalizer
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/**
 * Alarmas y temporizadores con CUALQUIER tiempo, y también modificarlos o borrarlos.
 *  - "temporizador de 1 hora 20 minutos", "timer de 90 segundos", "temporizador de hora y media", "pon un temporizador de tres cuartos de hora para la pasta"
 *  - "alarma a las 6 y cuarto de la mañana", "alarma a las 7:45", "alarma en 35 minutos", "alarma de lunes a viernes a las 6 llamada gimnasio"
 *  - "cambia la alarma de las 7 a las 8", "adelanta la alarma de las 7 diez minutos", "borra la alarma de las 7"
 *  - "cambia el temporizador a 25 minutos", "cancela el temporizador", "muestra mis alarmas"
 * Si falta el dato, lo pregunta y la siguiente frase ("Hola Génesis, veinte minutos") lo completa.
 */
object Reloj {
    private val ui = Handler(Looper.getMainLooper())
    private var pending = ""            // "timer" | "alarm": falta el tiempo
    private var pendingUntil = 0L
    /** Un número suelto, pero NO el "un/una" de "pon un temporizador" (que digitize convierte en "1 temporizador"). */
    private const val NUM_NOT_WORD = "\\b(\\d+)\\b(?!\\s*(?:temporizador|timer|alarma|cuenta))"
    // Constantes de Android 12+ escritas como texto: no existen en todos los compileSdk, pero el sistema las entiende igual.
    private const val ACTION_DELETE_ALARM = "android.intent.action.DELETE_ALARM"
    private const val ACTION_DISMISS_TIMER = "android.intent.action.DISMISS_TIMER"
    private const val NO_CLOCK = "No encontré una app de reloj para hacer eso."
    private val wakeRe = Regex("^((hola |oye |ok )?(genesis|jenesis|genesys|yenesis)[, ]*)")

    private fun fold(s: String): String = buildString(s.length) {
        for (ch in s) append(Normalizer.normalize(ch.toString(), Normalizer.Form.NFD)[0].lowercaseChar())
    }

    private fun go(c: Context, i: Intent): Boolean = try { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); c.startActivity(i); true } catch (e: Exception) { false }

    // ------------------------------------------------------------------ números en palabras → dígitos
    private val UNITS = mapOf("cero" to 0, "un" to 1, "uno" to 1, "una" to 1, "dos" to 2, "tres" to 3, "cuatro" to 4, "cinco" to 5,
        "seis" to 6, "siete" to 7, "ocho" to 8, "nueve" to 9, "diez" to 10, "once" to 11, "doce" to 12, "trece" to 13, "catorce" to 14,
        "quince" to 15, "dieciseis" to 16, "diecisiete" to 17, "dieciocho" to 18, "diecinueve" to 19, "veintiun" to 21, "veintiuno" to 21,
        "veintidos" to 22, "veintitres" to 23, "veinticuatro" to 24, "veinticinco" to 25, "veintiseis" to 26, "veintisiete" to 27,
        "veintiocho" to 28, "veintinueve" to 29)
    private val TENS = mapOf("veinte" to 20, "treinta" to 30, "cuarenta" to 40, "cincuenta" to 50, "sesenta" to 60, "setenta" to 70,
        "ochenta" to 80, "noventa" to 90)
    private val HUND = mapOf("cien" to 100, "ciento" to 100, "doscientos" to 200, "trescientos" to 300, "cuatrocientos" to 400,
        "quinientos" to 500, "seiscientos" to 600, "setecientos" to 700, "ochocientos" to 800, "novecientos" to 900)

    private fun digitize(s: String): String {
        val w = s.split(" ").filter { it.isNotEmpty() }
        val out = ArrayList<String>()
        var i = 0
        while (i < w.size) {
            if (w[i] in UNITS || w[i] in TENS || w[i] in HUND) {
                var j = i; var total = 0
                if (w[j] in HUND) { total += HUND.getValue(w[j]); j++ }
                if (j < w.size && w[j] in TENS) {
                    total += TENS.getValue(w[j]); j++
                    if (j + 1 < w.size && w[j] == "y" && (UNITS[w[j + 1]] ?: 0) in 1..9) { total += UNITS.getValue(w[j + 1]); j += 2 }
                } else if (j < w.size && w[j] in UNITS) { total += UNITS.getValue(w[j]); j++ }
                out.add(total.toString()); i = j
            } else { out.add(w[i]); i++ }
        }
        return out.joinToString(" ")
    }

    private fun clean(f: String): String {
        var t = f.replace(Regex("(\\d),(\\d)"), "$1.$2").replace(Regex("\\ba\\.m\\.?"), "am").replace(Regex("\\bp\\.m\\.?"), "pm")
        t = t.replace(Regex("[,;!?¿¡]"), " ").replace(Regex("\\.(?!\\d)"), " ").replace(Regex("\\s+"), " ").trim()
        return digitize(t)
    }

    // ------------------------------------------------------------------ duración: "1 hora 20 minutos y 30 segundos", "hora y media"…
    private fun parseDuration(d: String): Long? {
        var t = " $d "; var sec = 0.0; var found = false
        fun take(re: String, f: (MatchResult) -> Double) {
            val rx = Regex(re)
            var m = rx.find(t)
            while (m != null) {
                sec += f(m); found = true
                t = t.replaceRange(m.range, " ".repeat(m.value.length))
                m = rx.find(t)
            }
        }
        fun num(x: String) = x.toDouble()
        take("\\b3 cuartos de hora\\b") { 2700.0 }
        take("\\b(?:1 )?cuarto de hora\\b") { 900.0 }
        take("\\b(?:1 )?media hora\\b") { 1800.0 }
        take("(\\d+(?:\\.\\d+)?) ?(?:horas?|hrs?|h)\\b(?: y (media|cuarto))?") { m ->
            num(m.groupValues[1]) * 3600 + (if (m.groupValues[2] == "media") 1800.0 else if (m.groupValues[2] == "cuarto") 900.0 else 0.0)
        }
        take("\\bhora y media\\b") { 5400.0 }          // sin número delante ("temporizador de hora y media")
        take("\\bhora y cuarto\\b") { 4500.0 }
        take("(\\d+(?:\\.\\d+)?) ?(?:minutos?|mins?)\\b(?: y medio)?") { m ->
            num(m.groupValues[1]) * 60 + (if (m.value.endsWith("medio")) 30.0 else 0.0)
        }
        take("(\\d+(?:\\.\\d+)?) ?(?:segundos?|segs?)\\b") { m -> num(m.groupValues[1]) }
        return if (found && sec > 0) Math.round(sec) else null
    }

    private fun human(sec: Long): String {
        val h = sec / 3600; val m = (sec % 3600) / 60; val s = sec % 60
        val p = ArrayList<String>()
        if (h > 0) p.add("$h " + if (h == 1L) "hora" else "horas")
        if (m > 0) p.add("$m " + if (m == 1L) "minuto" else "minutos")
        if (s > 0) p.add("$s " + if (s == 1L) "segundo" else "segundos")
        return when (p.size) { 0 -> "0 segundos"; 1 -> p[0]; else -> p.dropLast(1).joinToString(", ") + " y " + p.last() }
    }

    // ------------------------------------------------------------------ hora del reloj: "a las 6 y cuarto de la mañana", "7:45", "a las 8 pm"
    private class T(val h: Int, val m: Int, val period: String)

    private val timeRe = Regex("\\blas?\\s+(\\d{1,2})(?:[:.](\\d{2})|\\s+(\\d{2})\\b(?!\\s*(?:minutos?|mins?|segundos?|segs?|horas?|hrs?|h)\\b)|\\s+y\\s+(\\d{1,2})\\b)?\\s*(y media|y cuarto|menos cuarto|en punto)?\\s*(?:de la (manana|tarde|noche|madrugada)|(am|pm))?")

    private fun times(d: String, loose: Boolean): List<T> {
        var dd = d.replace(Regex("(?<!las )(?<!la )(?<![\\d:.])(\\d{1,2}:\\d{2})"), "las $1")
        if (loose && Regex("^\\d").containsMatchIn(dd)) dd = "las $dd"
        return timeRe.findAll(dd).map { m ->
            var h = m.groupValues[1].toInt()
            var mm = m.groupValues[2].ifEmpty { m.groupValues[3] }.ifEmpty { m.groupValues[4] }.ifEmpty { "0" }.toInt()
            when (m.groupValues[5]) { "y media" -> mm = 30; "y cuarto" -> mm = 15; "menos cuarto" -> { h -= 1; mm = 45 } }
            T(h, mm.coerceIn(0, 59), m.groupValues[6].ifEmpty { m.groupValues[7] })
        }.toList()
    }

    /** Pasa a 24 h. Sin "de la mañana/tarde": elige la más cercana en el futuro (como hacen los asistentes). */
    private fun resolve(t: T): Pair<Int, Int> {
        val h = ((t.h % 24) + 24) % 24
        val cands = when {
            t.period == "tarde" || t.period == "pm" -> listOf(if (h < 12) h + 12 else h)
            t.period == "noche" -> listOf(if (h == 12) 0 else if (h in 6..11) h + 12 else h)
            t.period == "manana" || t.period == "am" || t.period == "madrugada" -> listOf(if (h == 12) 0 else h)
            h > 12 || h == 0 -> listOf(h)
            else -> listOf(h % 12, h % 12 + 12)
        }
        val now = System.currentTimeMillis()
        val best = cands.minByOrNull { hh ->
            Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, hh); set(Calendar.MINUTE, t.m); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
                if (timeInMillis <= now) add(Calendar.DAY_OF_YEAR, 1)
            }.timeInMillis
        } ?: cands[0]
        return best to t.m
    }

    private fun clockText(h: Int, m: Int): String =
        SimpleDateFormat("h:mm a", Locale("es")).format(Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, h); set(Calendar.MINUTE, m) }.time)

    // ------------------------------------------------------------------ días y etiqueta
    private val DOW = linkedMapOf("lunes" to Calendar.MONDAY, "martes" to Calendar.TUESDAY, "miercoles" to Calendar.WEDNESDAY,
        "jueves" to Calendar.THURSDAY, "viernes" to Calendar.FRIDAY, "sabado" to Calendar.SATURDAY, "domingo" to Calendar.SUNDAY)
    private val DAYNAME = mapOf(Calendar.MONDAY to "lunes", Calendar.TUESDAY to "martes", Calendar.WEDNESDAY to "miércoles",
        Calendar.THURSDAY to "jueves", Calendar.FRIDAY to "viernes", Calendar.SATURDAY to "sábados", Calendar.SUNDAY to "domingos")

    private fun days(d: String): List<Int> {
        if (Regex("\\b(todos los dias|cada dia|diaria|diario|a diario)\\b").containsMatchIn(d)) return DOW.values.toList()
        if (Regex("\\b(de lunes a viernes|entre semana|dias laborales|dias de semana|laborables)\\b").containsMatchIn(d))
            return listOf(Calendar.MONDAY, Calendar.TUESDAY, Calendar.WEDNESDAY, Calendar.THURSDAY, Calendar.FRIDAY)
        if (Regex("\\b(fines? de semana|sabados? y domingos?)\\b").containsMatchIn(d)) return listOf(Calendar.SATURDAY, Calendar.SUNDAY)
        return DOW.filter { Regex("\\b${it.key}s?\\b").containsMatchIn(d) }.values.toList()
    }

    private fun daysText(l: List<Int>): String = when {
        l.isEmpty() -> ""
        l.size == 7 -> ", todos los días"
        l.toSet() == setOf(Calendar.MONDAY, Calendar.TUESDAY, Calendar.WEDNESDAY, Calendar.THURSDAY, Calendar.FRIDAY) -> ", de lunes a viernes"
        else -> ", cada " + l.joinToString(", ") { DAYNAME[it] ?: "" }
    }

    private fun labelOf(r: String): String? {
        val m = Regex("(?i)\\b(?:que se llame|llamad[ao]|con el nombre( de)?|con nombre|etiqueta(?:da)?|nombre)\\s+(.+)$").find(r)
            ?: Regex("(?i)\\bpara\\s+(?!(?:la|las)\\s+(?:\\d|una|dos|tres|cuatro|cinco|seis|siete|ocho|nueve|diez|once|doce)\\b)(?!\\d)(.+)$").find(r)
            ?: return null
        var t = m.groupValues.last()
        t = t.replace(Regex("(?i)\\s+(?:a las?|a la|todos los|cada|de lunes|los (?:lunes|martes|mi[eé]rcoles|jueves|viernes|s[aá]bados|domingos)|en \\d)\\b.*$"), "")
        t = t.trim(' ', '.', ',', '!', '?')
        return if (t.isNotBlank() && t.length < 60) t.replaceFirstChar { it.uppercaseChar() } else null
    }

    // ------------------------------------------------------------------ acciones
    private fun setTimer(c: Context, sec: Long, label: String?): String {
        if (sec < 1) return "Dime un tiempo mayor que cero."
        if (sec > 86_400) return "El reloj de Android solo acepta temporizadores de hasta 24 horas."
        val i = Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, sec.toInt()).putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        if (label != null) i.putExtra(AlarmClock.EXTRA_MESSAGE, label)
        return if (go(c, i)) "Temporizador de ${human(sec)}" + (label?.let { ", $it" } ?: "") + ". Ya está corriendo." else NO_CLOCK
    }

    private fun setAlarm(c: Context, h: Int, m: Int, label: String?, days: List<Int>): String {
        val i = Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, h).putExtra(AlarmClock.EXTRA_MINUTES, m)
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        if (label != null) i.putExtra(AlarmClock.EXTRA_MESSAGE, label)
        if (days.isNotEmpty()) i.putIntegerArrayListExtra(AlarmClock.EXTRA_DAYS, ArrayList(days))
        return if (go(c, i)) "Alarma puesta a las ${clockText(h, m)}" + daysText(days) + (label?.let { ", $it" } ?: "") + "." else NO_CLOCK
    }

    private fun deleteAlarm(c: Context, h: Int, m: Int): Boolean {
        val act = if (Build.VERSION.SDK_INT >= 31) ACTION_DELETE_ALARM else AlarmClock.ACTION_DISMISS_ALARM
        return go(c, Intent(act).putExtra(AlarmClock.EXTRA_ALARM_SEARCH_MODE, AlarmClock.ALARM_SEARCH_MODE_TIME)
            .putExtra(AlarmClock.EXTRA_HOUR, h).putExtra(AlarmClock.EXTRA_MINUTES, m).putExtra(AlarmClock.EXTRA_IS_PM, h >= 12)
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true))
    }

    private fun dismissTimer(c: Context): Boolean =
        if (Build.VERSION.SDK_INT >= 31) go(c, Intent(ACTION_DISMISS_TIMER)) else go(c, Intent(AlarmClock.ACTION_SHOW_TIMERS))

    // ------------------------------------------------------------------ punto de entrada
    fun handle(c: Context, raw: String): String? {
        var f = fold(raw); var r = raw
        wakeRe.find(f)?.let { m -> val n = m.range.last + 1; f = f.substring(n); r = r.substring(n) }
        r = r.trim()
        val d = clean(f)
        if (d.isEmpty()) return null

        val alarmW = Regex("\\balarmas?\\b|\\bdespiertame\\b|\\bdespertador\\b").containsMatchIn(d)
        val timerW = Regex("\\btemporizador(es)?\\b|\\btimer\\b|\\bcuenta (regresiva|atras)\\b").containsMatchIn(d)
        val now = System.currentTimeMillis()

        // Le faltaba el tiempo y ahora lo dices ("Hola Génesis, veinte minutos")
        if (!alarmW && !timerW) {
            if (pending.isNotEmpty() && now < pendingUntil) {
                if (pending == "timer") {
                    val sec = parseDuration(d) ?: Regex("^(\\d+)$").find(d)?.let { it.groupValues[1].toLong() * 60 }
                    if (sec != null) { pending = ""; return setTimer(c, sec, labelOf(r)) }
                } else {
                    val t = times(d, true).firstOrNull()
                    if (t != null) { pending = ""; val (h, m) = resolve(t); return setAlarm(c, h, m, labelOf(r), days(d)) }
                    val sec = parseDuration(d)
                    if (sec != null && sec <= 86_400) { pending = ""; return alarmIn(c, sec, labelOf(r)) }
                }
            }
            return null
        }

        val ts = times(d, false)
        val dur = parseDuration(d)
        val verbModify = Regex("\\b(cambia|cambiar|cambiame|modifica|modificar|mueve|mover|pasa|pasar|edita|editar|actualiza|actualizar|reprograma|reprogramar|adelanta|adelantar|atrasa|atrasar|retrasa|retrasar|corrige|corregir)\\w*").containsMatchIn(d)
        val verbDelete = Regex("\\b(borra|borrar|elimina|eliminar|quita|quitar|cancela|cancelar|apaga|apagar|desactiva|desactivar|deten|detener)\\b").containsMatchIn(d)

        // ---- Mostrar la lista ----
        if (ts.isEmpty() && dur == null && !verbModify && !verbDelete &&
            Regex("\\b(muestra|muestrame|abre|abrir|ver|mis|lista|que|cuales|cuantas)\\b").containsMatchIn(d)) {
            val ok = go(c, Intent(if (timerW && !alarmW) AlarmClock.ACTION_SHOW_TIMERS else AlarmClock.ACTION_SHOW_ALARMS))
            return if (ok) "Te abrí " + (if (timerW && !alarmW) "tus temporizadores." else "tus alarmas.") else NO_CLOCK
        }

        // ---- Modificar ----
        if (verbModify) {
            if (timerW && !alarmW) {
                // "cambia el temporizador de 10 minutos a 15 minutos": vale el tiempo NUEVO (lo que va tras la última " a "), no la suma
                val tail = if (" a " in d) d.substringAfterLast(" a ") else d
                val sec = parseDuration(tail) ?: Regex("^\\s*(\\d+)\\s*$").find(tail)?.let { it.groupValues[1].toLong() * 60 } ?: dur
                    ?: Regex(NUM_NOT_WORD).find(d)?.let { it.groupValues[1].toLong() * 60 }
                    ?: return "Dime el nuevo tiempo, por ejemplo: cambia el temporizador a 25 minutos."
                dismissTimer(c)
                ui.postDelayed({ setTimer(c, sec, labelOf(r)) }, 1500)
                return "Cambiando el temporizador a ${human(sec)}."
            }
            val shift = Regex("\\b(adelanta|adelantar|atrasa|atrasar|retrasa|retrasar)\\w*").find(d)?.value
            var old: Pair<Int, Int>? = null; val new: Pair<Int, Int>
            if (shift != null && ts.isNotEmpty() && dur != null) {
                old = resolve(ts[0])
                val delta = (dur / 60).toInt() * (if (shift.startsWith("adelant")) -1 else 1)
                val tot = ((old.first * 60 + old.second + delta) % 1440 + 1440) % 1440
                new = (tot / 60) to (tot % 60)
            } else if (ts.size >= 2) { old = resolve(ts.first()); new = resolve(ts.last()) }
            else if (ts.size == 1) new = resolve(ts[0])
            else return "Dime la nueva hora. Por ejemplo: cambia la alarma de las 7 a las 8."
            if (old != null) {
                deleteAlarm(c, old.first, old.second)
                val nh = new.first; val nm = new.second; val lb = labelOf(r); val dy = days(d)
                ui.postDelayed({ setAlarm(c, nh, nm, lb, dy) }, 1800)
                return "Cambiando la alarma de las ${clockText(old.first, old.second)} a las ${clockText(new.first, new.second)}."
            }
            return setAlarm(c, new.first, new.second, labelOf(r), days(d)) + " Para quitar la anterior dime: borra la alarma de las 7."
        }

        // ---- Borrar / cancelar ----
        if (verbDelete) {
            if (timerW && !alarmW) return if (dismissTimer(c)) "Cancelé el temporizador." else NO_CLOCK
            if (ts.isNotEmpty()) { val (h, m) = resolve(ts[0]); return if (deleteAlarm(c, h, m)) "Borré la alarma de las ${clockText(h, m)}." else NO_CLOCK }
            if (Regex("\\btodas\\b").containsMatchIn(d)) return if (go(c, Intent(AlarmClock.ACTION_SHOW_ALARMS))) "Te abrí tus alarmas para que borres las que quieras: Android no me deja borrarlas todas de golpe." else NO_CLOCK
            return if (go(c, Intent(AlarmClock.ACTION_DISMISS_ALARM).putExtra(AlarmClock.EXTRA_ALARM_SEARCH_MODE, AlarmClock.ALARM_SEARCH_MODE_NEXT))) "Apagué la alarma." else NO_CLOCK
        }

        // ---- Temporizador ----
        if (timerW) {
            val sec = dur ?: Regex(NUM_NOT_WORD).find(d)?.let { it.groupValues[1].toLong() * 60 }      // "temporizador de 5" = 5 minutos
            if (sec == null) {
                pending = "timer"; pendingUntil = now + 60_000
                return "¿De cuánto tiempo? Puede ser cualquiera, por ejemplo: 1 hora 20 minutos y 30 segundos."
            }
            return setTimer(c, sec, labelOf(r))
        }

        // ---- Alarma ----
        if (ts.isNotEmpty()) { val (h, m) = resolve(ts[0]); return setAlarm(c, h, m, labelOf(r), days(d)) }
        if (dur != null && Regex("\\ben \\d").containsMatchIn(d)) return if (dur <= 86_400) alarmIn(c, dur, labelOf(r)) else "El reloj de Android solo acepta alarmas dentro de las próximas 24 horas."
        pending = "alarm"; pendingUntil = now + 60_000
        return "¿A qué hora? Por ejemplo: a las 6 y cuarto de la mañana, a las 7:45, o en 35 minutos. También puedo repetirla: todos los días o de lunes a viernes."
    }

    private fun alarmIn(c: Context, sec: Long, label: String?): String {
        val cal = Calendar.getInstance().apply { timeInMillis = System.currentTimeMillis() + sec * 1000 }
        return setAlarm(c, cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), label, emptyList()).replace("Alarma puesta", "Alarma dentro de ${human(sec)}, puesta")
    }
}
