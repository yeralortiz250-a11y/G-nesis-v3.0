package com.jarvis.assistant

import android.content.Context
import java.util.Random

/**
 * Habla de su IA y la usa en más respuestas.
 *
 *  - [about]: contesta cuando le preguntas por su IA ("¿qué IA tienes?", "¿cómo funciona tu IA?", "¿dónde guardas tu IA?"…).
 *    No necesita encender la IA: responde con texto propio y con su estado real (instalada, dormida, descargando…).
 *  - [handle]: órdenes que usan la IA interna directamente (preguntar, explicar, traducir, resumir, corregir, escribir,
 *    ideas, consejos, comparar, pros y contras, opinión, planes, charla) y seguimientos sobre su última respuesta
 *    ("explícamelo más fácil", "resúmelo", "tradúcelo al inglés").
 *
 * Todo corre en el celular, sin internet ni clave de API (ver IA.kt). Hay que llamarlo desde un hilo de fondo.
 */
object IATalk {
    private val rnd = Random()
    private fun pick(vararg o: String) = o[rnd.nextInt(o.size)]

    // ------------------------------------------------------------------ última respuesta (para los seguimientos)
    @Volatile private var last = ""
    @Volatile private var lastNotice = ""

    /** Lo llama CommandEngine con cada respuesta, para poder reformularla si el usuario lo pide. */
    fun remember(reply: String) {
        if (reply.length > 15 && reply != lastNotice) last = reply.take(700)
    }

    private fun notice(t: String): String { lastNotice = t; return t }

    private const val IAS = "(?:ia|inteligencia artificial|cerebro de ia|cerebro artificial|modelo de ia)"

    private val LANGS = mapOf(
        "ingles" to "inglés", "espanol" to "español", "frances" to "francés", "portugues" to "portugués",
        "italiano" to "italiano", "aleman" to "alemán", "japones" to "japonés", "chino" to "chino",
        "catalan" to "catalán", "ruso" to "ruso", "coreano" to "coreano", "latin" to "latín"
    )
    private val LANG = LANGS.keys.joinToString("|")

    private val BASE = "Eres Génesis, un asistente de voz personal. Respondes siempre en español, con tono cercano y natural, " +
        "sin listas, sin asteriscos y sin formato, porque tu respuesta se lee en voz alta. "

    // Temas donde Génesis ya tiene sus propias lecciones y reglas: no los secuestramos con la IA.
    private val FINANCE = Regex("invers|bolsa|trading|\\btrade\\b|acciones|cripto|stop loss|dinero|finanz|forex|prestamo|credito")

    private class T(val sys: String, val user: String, val max: Int = 600, val learn: Boolean = false, val intro: String = "")

    /** Quita signos y espacios sobrantes de los extremos. */
    private fun tidy(s: String) = s.replace(Regex("[¿?¡!]"), "").trim().trimEnd('.', ',', ';').trim()

    // ================================================================== 1) PREGUNTAS SOBRE SU IA
    private fun stateLine(c: Context): String {
        val st = when (IA.state(c)) {
            IA.Est.LISTA -> "Ahora mismo la tengo instalada ${IA.lugar(c)} y está " +
                (if (IA.isLoaded()) "encendida." else "dormida, para no gastar batería ni memoria.")
            IA.Est.BAJANDO -> "Ahora mismo la estoy descargando, voy por el ${IA.percent(c)} por ciento."
            IA.Est.NO -> "Todavía no la tengo instalada: dime \"descarga tu IA\" y la bajo."
        }
        return st + (if (!Prefs.iaOn(c)) " Eso sí, el encendido automático está desactivado." else "")
    }

    /** Devuelve la respuesta si [s] (normalizado, sin tildes) pregunta por la IA de Génesis; si no, null. */
    fun about(c: Context, s0: String): String? {
        val s = tidy(s0)
        val hasIa = Regex("\\b(?:ia|inteligencia artificial|cerebro de ia|cerebro artificial|qwen)\\b").containsMatchIn(s)
        val howThink = Regex("^(?:como|con que) (?:piensas|razonas|respondes|contestas)$").matches(s)
        if (!hasIa && !howThink) return null
        // Ahí hablan de la IA en general, no de la de Génesis ("qué es la inteligencia artificial")
        val mine = Regex("\\b(?:tu|tus)\\b|^(?:eres|tienes|usas|utilizas|funcionas)\\b|\\b(?:usas|utilizas|tienes|tengas)\\b|\\bqwen\\b").containsMatchIn(s)
        if (!mine && !howThink) return null
        // Las órdenes de manejo (descarga, enciende, apaga, mueve…) las resuelve IA.command
        if (Regex("^(?:descarga|instala|baja|prepara|enciende|activa|prende|apaga|desactiva|desconecta|quita|pon|mueve|pasa|guarda|lleva|cambia|olvida|borra)\\b")
                .containsMatchIn(s)) return null
        val starter = Regex("^(?:que|cual|cuales|como|cuando|donde|cuanto|cuanta|por que|para que|eres|tienes|usas|utilizas|hablame|habla|cuentame|explicame|" +
            "dime|platicame|ensename|sabes|funciona|funcionas|es|esta|puedes|puedo|ayuda|comandos|ordenes)\\b").containsMatchIn(s)
        if (!starter && !howThink) return null
        // Órdenes directas ("dime con tu ia ...", "pregúntale a tu ia ...") son para handle()
        if (explicitUse(s) != null) return null
        // El estado corto ("cómo está tu IA", "estado de tu IA") ya lo cuenta IA.command
        if (Regex("^(?:como esta|como va|que tal|estado)\\b").containsMatchIn(s)) return null

        return when {
            Regex("comandos|ordenes|ejemplos|que puedo (?:pedir|hacer|decir)|que (?:puedes|sabes) hacer|^ayuda|para que sirve").containsMatchIn(s) -> commandsHelp()
            Regex("\\b(?:donde|guardas|almacenas|vive|pesa|ocupa|espacio|tamano|megas|gigas|memoria|tarjeta)\\b").containsMatchIn(s) ->
                "Mi modelo pesa unos quinientos cuarenta y siete megas y vive en el almacenamiento de la app: en el teléfono, o en la tarjeta SD si hay poco espacio. " +
                    "No puede estar en la nube porque necesita ejecutarse aquí mismo. " + stateLine(c) +
                    " Puedes decirme \"pon tu IA en la SD\" o \"pon tu IA en el teléfono\" para moverla."
            Regex("\\b(?:internet|wifi|gratis|cuesta|cobra|clave|api|pagar|pago|offline|conexion|datos)\\b").containsMatchIn(s) ->
                "Mi IA es gratis, funciona sin internet y no usa clave de API, porque el modelo corre dentro de tu celular. " +
                    "Solo necesito conexión una vez, para descargarlo: son unos quinientos cuarenta y siete megas, y por defecto lo bajo solo con Wi-Fi. " + stateLine(c)
            Regex("\\b(?:cuando|funciona|trabaja|enciende|apaga|decide|bateria|ram|pasos|piensas|razonas|respondes|aprendes|contestas)\\b").containsMatchIn(s) ->
                "Trabajo por pasos. Primero busco en mi memoria y en lo que he aprendido. Si no lo sé y hay internet, lo busco en la web. " +
                    "Solo si tampoco lo encuentro, enciendo mi IA, pienso la respuesta y la guardo para no necesitarla la próxima vez. " +
                    "Si estuvo un minuto sin usarse, se apaga sola para liberar batería y memoria. " +
                    "Además puedes pedírmela directamente: di \"pregúntale a tu IA…\", \"explícame…\" o \"escríbeme un poema sobre…\"."
            else -> pick(
                "Tengo una IA propia: un modelo de lenguaje pequeño llamado Qwen dos punto cinco, de licencia libre, que corre dentro de tu celular sin internet ni clave de API. " +
                    "La uso cuando mi memoria y la web no saben la respuesta, y lo que contesta lo guardo para no necesitarla después. " +
                    "Como es pequeña, a veces se equivoca; si te dice algo mal, dime \"eso está mal\" y lo borro. " + stateLine(c),
                "Sí, tengo mi propia inteligencia artificial: Qwen de quinientos millones de parámetros, gratis y local, así que funciona sin internet. " +
                    "Me sirve para explicar, traducir, escribir, dar ideas y responder cuando no encuentro algo. Es pequeña, así que no es perfecta, pero aprende de lo que le corriges. " +
                    stateLine(c)
            )
        }
    }

    private fun commandsHelp() =
        "Con mi IA puedes pedirme muchas cosas. Preguntas directas: \"pregúntale a tu IA por qué el cielo es azul\". " +
            "Explicaciones: \"explícame la inflación como si tuviera cinco años\". " +
            "Escribir: \"escríbeme un poema sobre el mar\" o \"redáctame un mensaje para mi jefe pidiendo un día libre\". " +
            "Traducir: \"traduce al inglés buenos días\". Resumir o corregir un texto. " +
            "Ideas y consejos: \"dame ideas para un regalo\". Comparar: \"compara gatos y perros\". " +
            "También pros y contras, mi opinión, planes y rutinas, o simplemente \"platiquemos de viajes\". " +
            "Y sobre mi última respuesta puedes decir: \"explícamelo más fácil\", \"resúmelo\" o \"tradúcelo al inglés\"."

    // ================================================================== 2) ÓRDENES QUE USAN LA IA
    private fun explicitUse(s: String): String? {
        if (Regex("^(?:usa|pon|mueve|pasa|guarda|lleva|cambia)\\b").containsMatchIn(s) &&
            Regex("\\b(?:sd|tarjeta|memoria externa|memoria interna|telefono|celular)\\b").containsMatchIn(s)) return null
        return Regex("^(?:preguntale|pregunta|consulta|consultale|dime|usa|utiliza|responde|contesta|piensa|razona|averigua|investiga)(?:le)?" +
                "(?: a| con| en| mediante| usando)? (?:tu|la|mi|el) $IAS[,:]? (.{3,})$").find(s)?.groupValues?.get(1)
            ?: Regex("^(?:segun|con|de acuerdo con) (?:tu|la) $IAS[,:]? (.{3,})$").find(s)?.groupValues?.get(1)
            ?: Regex("^(?:ia|inteligencia artificial)[,:] ?(.{3,})$").find(s)?.groupValues?.get(1)
    }

    /**
     * Para PRECALENTAR: ¿lo que se está oyendo (aunque vaya a medias) parece una petición para la IA?
     * Si sí, el servicio enciende el modelo mientras terminas de hablar, y cuando acabas ya está listo.
     * [raw] viene tal cual del reconocedor de voz. No tiene efectos secundarios.
     */
    fun wantsIA(raw: String): Boolean {
        return try {
            val s = tidy(Brain.norm(raw).replace(Regex("[^a-z0-9 ,:]"), " ").replace(Regex("\\s+"), " "))
            if (s.length < 6) return false
            val t = s.replace(Regex("^(?:hola |oye |ok )?(?:genesis|jenesis|genesys|yenesis),? ?"), "").trim()
            ENTER.matches(t) || Regex("\\b(?:tu|la|mi) $IAS\\b").containsMatchIn(t) || route(t) != null
        } catch (_: Exception) { false }
    }

    private fun route(s: String): T? {
        // ---- Preguntar directamente a su IA ----
        explicitUse(s)?.let { q ->
            return T(BASE + "Responde con claridad en máximo 3 oraciones. Si no estás seguro de algo, dilo; no inventes datos.",
                q, 600, learn = true, intro = "Según mi IA interna: ")
        }

        // ---- Seguimientos sobre lo último que dijo ----
        if (Regex("^(?:explicamelo|explicalo|explicame eso|explica eso|dimelo|dilo|repitelo)(?: otra vez)?(?: de forma| de manera| mas| con palabras)*(?: mas)? ?(?:sencill\\w+|simple|facil|claro|clara)$").matches(s))
            return T(BASE + "Explica el texto del usuario de forma mucho más sencilla, con palabras simples, en máximo 3 oraciones.", last, 500)
        if (Regex("^(?:resumelo|resumeme eso|resume eso|resume lo que dijiste|resume tu respuesta|hazlo mas corto|mas corto|dilo mas corto|acortalo|en una frase|dimelo en una frase|en pocas palabras)$").matches(s))
            return T(BASE + "Resume el texto del usuario en una sola oración corta.", last, 300)
        if (Regex("^(?:amplialo|amplia eso|dame mas detalles|mas detalles|dime mas|cuentame mas|profundiza|explica mas|desarrollalo)$").matches(s))
            return T(BASE + "Amplía el texto del usuario con más detalles interesantes y correctos, en máximo 4 oraciones.", last, 700)
        Regex("^(?:traducelo|traduce eso|traduce lo que dijiste|traduce tu respuesta)(?: al| a| en)? ?($LANG)$").find(s)?.let { m ->
            val l = LANGS[m.groupValues[1]]!!
            return T("Eres un traductor profesional. Traduce el texto del usuario al $l. Responde únicamente con la traducción.", last, 700)
        }
        if (Regex("^(?:reformulalo|reformula eso|dilo de otra forma|dilo con otras palabras|con otras palabras|parafraseamelo)$").matches(s))
            return T(BASE + "Di lo mismo que el texto del usuario pero con otras palabras, en máximo 3 oraciones.", last, 500)
        if (Regex("^(?:dame un ejemplo|ponme un ejemplo|con un ejemplo|un ejemplo)$").matches(s))
            return T(BASE + "Da un ejemplo concreto y cotidiano de lo que dice el texto del usuario, en máximo 3 oraciones.", last, 500)

        // ---- Traducir ----
        Regex("^(?:traduce|traduceme|traducir)(?: esto| la frase| el texto| lo siguiente)?(?: al| a| en)? ($LANG)[:,]? (.+)$").find(s)?.let { m ->
            return translate(LANGS[m.groupValues[1]]!!, m.groupValues[2])
        }
        Regex("^(?:traduce|traduceme)(?: esto| la frase| el texto| lo siguiente)?[:,]? (.+?) (?:al|a|en) ($LANG)$").find(s)?.let { m ->
            return translate(LANGS[m.groupValues[2]]!!, m.groupValues[1])
        }
        Regex("^como se dice (.+?) en ($LANG)$").find(s)?.let { m -> return translate(LANGS[m.groupValues[2]]!!, m.groupValues[1]) }

        // ---- Resumir y corregir un texto que le dictas ----
        Regex("^(?:resume|resumeme|resumir)(?: este| el| esto| lo siguiente)?(?: texto)?[:,]? (.{40,})$").find(s)?.let { m ->
            val t = m.groupValues[1]
            if (!Regex("^(?:la |el |esta |ese )?(?:pagina|sitio|web|articulo)|http|www\\.|\\.com").containsMatchIn(t))
                return T(BASE + "Resume el texto del usuario en máximo 2 oraciones claras.", t, 400)
        }
        Regex("^(?:corrige|corrigeme|corregir)(?: este| el| esto| lo siguiente)?(?: texto| frase| mensaje| escrito)?(?: ortograficamente)?[:,]? (.{4,})$").find(s)?.let { m ->
            return T("Corrige la ortografía y la gramática del texto del usuario. Responde únicamente con el texto corregido.", m.groupValues[1], 500)
        }
        Regex("^(?:reescribe|reescribeme|parafrasea|parafraseame|redacta mejor|mejora la redaccion de)(?: este| el| esto| lo siguiente)?(?: texto| frase| mensaje)?" +
            "(?: de forma| de manera| en tono| con tono)?(?: (formal|informal|amable|profesional|divertido|educado|claro|breve|sencillo|cordial))?[:,]? (.{4,})$").find(s)?.let { m ->
            val tone = m.groupValues[1].ifEmpty { "más claro y natural" }
            return T("Reescribe el texto del usuario con un tono $tone, conservando su significado. Responde únicamente con el texto reescrito.", m.groupValues[2], 600)
        }

        // ---- Explicar ----
        Regex("^(?:explicame|explica|explicanos)(?: me)?(?: de forma| con palabras| de manera)?(?: muy)?(?: sencilla| simple| facil| clara)? (.{3,})$").find(s)?.let { m ->
            var topic = m.groupValues[1]
            if (Regex("^como (?:aprendiste|sabes|supiste|lo aprendiste|lo sabes)").containsMatchIn(topic)) return null   // eso es de Saber.kt
            val kid = Regex("\\s*(?:como si (?:fuera|fuese|tuviera) (?:un |una )?(?:nino|nina|chiquito|pequeno)?(?: de)? ?(?:cinco|5|seis|6|siete|7)? ?(?:anos)?|como a un nino|para un nino|como si tuviera (?:cinco|5) anos)$")
            val isKid = kid.containsMatchIn(topic)
            topic = topic.replace(kid, "").trim()
            if (topic.length < 3 || topic.matches(Regex("^(?:eso|esto|lo anterior|lo ultimo)$"))) return null
            val style = if (isKid) "Explícalo como a un niño de cinco años, con palabras muy simples y una comparación cotidiana, en máximo 4 oraciones."
                else "Explica el tema de forma sencilla y clara, en máximo 4 oraciones, con un ejemplo corto si ayuda."
            return T(BASE + style, "Explícame $topic", 650, learn = !isKid && !FINANCE.containsMatchIn(topic), intro = "")
        }

        // ---- Escribir cosas creativas con tema ----
        Regex("^(?:escribe|escribeme|hazme|componme|compon|inventa|inventame|crea|creame|dime|cuentame|dame|recitame)(?: me)? (un|una) " +
            "(poema|verso|rima|cuento|historia|chiste|adivinanza|acertijo|trabalenguas|frase|eslogan|slogan|saludo|discurso|haiku|brindis|dedicatoria|anecdota|fabula|piropo|felicitacion|agradecimiento) " +
            "((?:muy )?(?:corto|corta|breve|gracioso|graciosa|divertido|divertida|bonito|bonita|romantico|romantica|triste|largo|larga) )?" +
            "(?:de|sobre|acerca de|para|del|con|donde|que hable de)(?: la| el| los| las| un| una)? (.+)$").find(s)?.let { m ->
            val kind = m.groupValues[2]; val mod = m.groupValues[3].trim()
            val topic = m.groupValues[4]
            return T(BASE + "Eres creativo. Cumple exactamente lo pedido en máximo 6 oraciones o versos cortos, sin título ni comentarios adicionales.",
                "Quiero ${m.groupValues[1]} $kind ${if (mod.isNotEmpty()) "$mod " else ""}sobre $topic.", 900)
        }
        // ... y sin tema, se inventa uno
        Regex("^(?:cuentame|dime|inventa|inventame|escribeme|ponme) (un|una) (cuento|historia|adivinanza|acertijo|poema|trabalenguas|fabula|haiku)(?: corto| corta| breve| de ninos| para dormir)*$").find(s)?.let { m ->
            val theme = pick("un dragón tímido", "un robot que quiere aprender a cantar", "un gato astronauta", "el mar de noche", "una abuela inventora", "un faro en una isla")
            return T(BASE + "Eres creativo. Cumple exactamente lo pedido en máximo 6 oraciones o versos cortos, sin título ni comentarios adicionales.",
                "Quiero ${m.groupValues[1]} ${m.groupValues[2]} sobre $theme.", 900)
        }

        // ---- Redactar mensajes, cartas y textos (sin chocar con \"manda mensaje a X diciendo…\") ----
        Regex("^(?:redacta|redactame|dictame|prepara|preparame)(?: me)? (?:un|una) (mensaje|correo|email|carta|nota|texto|disculpa|invitacion|agradecimiento|respuesta|publicacion|post|descripcion) " +
            "(?:de|para|sobre|a|donde|que|pidiendo|invitando|agradeciendo|felicitando)(?: la| el| los| las| un| una)? ?(.+)$").find(s)?.let { m ->
            if (!Regex("\\b(?:diciendo|que diga)\\b").containsMatchIn(s))
                return T(BASE + "Redacta el texto pedido, listo para enviar, en máximo 5 oraciones, cordial y sin asunto ni comentarios extra.",
                    "Quiero que redactes " + s.replace(Regex("^\\S+(?: me)? "), ""), 900)
        }

        // ---- Ideas, sugerencias, consejos… ----
        Regex("^(?:dame|dime|sugiere|sugiereme|propon|proponme|genera|generame|recomiendame|piensa)(?: me)? " +
            "(?:unas |unos |algunas |algunos |\\d+ |tres |cuatro |cinco |seis |diez |una |un )?" +
            "(ideas?|sugerencias?|opciones|alternativas|nombres?|excusas?|consejos?|tips?|trucos?|recomendaciones|recomendacion|razones|razon|ejemplos?|regalos?|motivos|formas|maneras|actividades|planes|temas|titulos?|hashtags|apodos) " +
            "(?:de|para|sobre|acerca de|con|en|que)(?: la| el| los| las| un| una)? (.+)$").find(s)?.let { m ->
            if (FINANCE.containsMatchIn(m.groupValues[2])) return null
            return T(BASE + "Da exactamente lo que se pide, con máximo 4 ideas cortas dichas en una o dos oraciones fluidas, sin numerar.",
                "Dame ${m.groupValues[1]} para ${m.groupValues[2]}", 700)
        }

        // ---- Pros y contras ----
        Regex("^(?:(?:dime|dame|cuales son|enumera|enumerame)(?: las| los)? )?(pros y contras|ventajas y desventajas|ventajas|desventajas) " +
            "(?:de usar|de tener|de hacer|de estudiar|de comprar|de la|del|de) (.+)$").find(s)?.let { m ->
            if (FINANCE.containsMatchIn(m.groupValues[2])) return null
            return T(BASE + "Menciona dos ventajas y dos desventajas del tema en un par de oraciones fluidas, sin listas.",
                "${m.groupValues[1]} de ${m.groupValues[2]}", 600)
        }

        // ---- Comparar ----
        (Regex("^(?:compara|comparame|comparar)(?: a| al| el| la| los| las)? (.+?) (?:y el|y la|y|con|contra|vs|versus) (.+)$").find(s)
            ?: Regex("^(?:cual es la diferencia entre|que diferencia hay entre|en que se diferencian|diferencias entre|diferencia entre) (.+?) (?:y|con|contra) (.+)$").find(s)
            ?: Regex("^que es mejor,? (.+?) o (.+)$").find(s))?.let { m ->
            val a = m.groupValues[1]; val b = m.groupValues[2]
            if (FINANCE.containsMatchIn("$a $b")) return null
            return T(BASE + "Compara brevemente las dos cosas en máximo 4 oraciones, marcando la diferencia principal.", "Compara $a con $b", 650)
        }

        // ---- Opinión y decisiones ----
        Regex("^(?:que (?:opinas|piensas|crees|te parece)(?: de| sobre| acerca de)?|cual es tu opinion (?:de|sobre|acerca de)|tu opinion (?:de|sobre)|opina (?:de|sobre)) (.{3,})$").find(s)?.let { m ->
            if (FINANCE.containsMatchIn(m.groupValues[1])) return null
            return T(BASE + "Da una opinión breve y equilibrada, en máximo 3 oraciones. Si el tema es polémico, presenta ambos lados sin tomar partido.",
                "¿Qué opinas de ${m.groupValues[1]}?", 600)
        }
        (Regex("^ayudame a (?:decidir|elegir|escoger)(?: entre)? (.+)$").find(s)
            ?: Regex("^(?:que me conviene|que elijo|que escojo)(?: mas)?:? (.+)$").find(s))?.let { m ->
            if (FINANCE.containsMatchIn(m.groupValues[1])) return null
            return T(BASE + "Ayuda a decidir: da dos criterios clave y una recomendación clara, en máximo 4 oraciones.", "Ayúdame a decidir ${m.groupValues[1]}", 650)
        }

        // ---- Planes, rutinas, recetas… ----
        Regex("^(?:dame|hazme|armame|preparame|planeame|organizame|crea|creame|sugiereme|recomiendame)(?: me)? (?:un|una) " +
            "(plan|rutina|itinerario|menu|esquema|guia|receta|checklist) (?:de|para|sobre|del|con)(?: la| el| los| las)? (.+)$").find(s)?.let { m ->
            if (FINANCE.containsMatchIn(m.groupValues[2])) return null
            return T(BASE + "Arma lo pedido de forma práctica, en máximo 5 oraciones, diciendo los pasos en orden y sin listas con símbolos.",
                "Quiero " + s.replace(Regex("^\\S+(?: me)? "), ""), 800)
        }

        // ---- Charlar ----
        Regex("^(?:platica|platicame|conversemos|charlemos|hablemos|charla|conversa|platiquemos)(?: conmigo)?(?: de| sobre| acerca de)? ?(.*)$").find(s)?.let { m ->
            val topic = m.groupValues[1].trim()
            if (topic.isEmpty()) return T("", "", 0, intro = "¿De qué quieres hablar?")
            return T(BASE + "Conversa de forma natural, curiosa y amistosa, en máximo 3 oraciones, y termina con una pregunta corta para seguir platicando.",
                "Quiero platicar sobre $topic", 600)
        }
        return null
    }

    private fun translate(lang: String, text: String): T =
        T("Eres un traductor profesional. Traduce el texto del usuario al $lang. Responde únicamente con la traducción.", text, 500)

    // ================================================================== 3) ENTRADA PRINCIPAL
    /**
     * [s] ya viene normalizado (minúsculas, sin tildes). Devuelve la respuesta, o null si no era una orden para la IA.
     */
    fun handle(c: Context, brain: Brain, s0: String, say: ((String) -> Unit)?): String? {
        val s = tidy(s0)
        val t = route(s) ?: return null
        if (t.max == 0) return t.intro                                         // pregunta de vuelta (charla sin tema)
        if (t.user.isBlank()) return notice("Todavía no he dicho nada que pueda reformular. Pregúntame algo primero.")
        IA.unavailable(c)?.let { return notice(it) }
        val a = IA.generate(c, t.sys, t.user, say, t.max, t.intro)
            ?: return notice("No logré que mi IA respondiera esta vez. Prueba de nuevo, o dímelo con otras palabras.")
        if (t.learn) IA.learn(c, brain, s, a)                                  // lo que explicó queda en su base: la próxima ya lo sabe
        return if (IA.streamed()) IA.tail() else t.intro + a                   // si ya fue diciendo las primeras frases, solo falta el final
    }

    // ================================================================== 4) MODO CONVERSACIÓN LIBRE ("usa tu IA")
    // Génesis habla contigo como una persona: sin "Hola Génesis" en cada frase, con memoria de lo último que dijeron
    // y con la IA interna siempre encendida (más rápido). Las órdenes de siempre (abrir apps, llamar, volumen…) siguen funcionando.
    @Volatile var chatOn = false
        private set
    @Volatile private var chatUntil = 0L
    @Volatile private var appCtx: Context? = null
    private val hist = ArrayDeque<Pair<String, String>>()
    private const val CHAT_IDLE_MS = 4 * 60_000L

    private val CHAT_SYS = "Eres Génesis, un amigo cercano que conversa por voz con su usuario. Hablas como una persona real: español natural y coloquial, " +
        "frases cortas, con emoción y curiosidad, sin sonar a robot ni a asistente. Nunca digas \"como IA\" ni \"no tengo sentimientos\". " +
        "Responde en una o dos oraciones y, de vez en cuando, haz una pregunta corta para seguir la charla. " +
        "Si no sabes algo, dilo con naturalidad; no inventes datos. No uses listas, emojis ni formato."

    private val ENTER = Regex(
        "^(?:usa|utiliza) (?:tu|la|mi) $IAS$" +
        "|^(?:usa|utiliza|activa|enciende|prende|ponte en|pon) (?:tu|la|mi) $IAS para (?:que )?(?:hablemos|hablar|platicar|platiquemos|conversar|conversemos|charlar|charlemos)(?: conmigo)?(?: libremente| libre| un rato| como persona| como una persona| como una persona real| como amigos)*$" +
        "|^(?:hablemos|platiquemos|conversemos|charlemos|hablame|platicame)(?: libremente| libre| un rato| como persona| como una persona| como una persona real| como amigos)*$" +
        "|^(?:platica|conversa|charla|habla) conmigo(?: libremente| libre| un rato| como persona| como una persona| como una persona real| como un amigo| como amigos)*$" +
        "|^modo (?:conversacion|charla|platica|libre|amigo|persona)$" +
        "|^(?:quiero|vamos a) (?:hablar|platicar|conversar|charlar)(?: contigo)?(?: libremente| libre| un rato)*$")

    private val EXIT = Regex(
        "^(?:ya no (?:quiero )?(?:hablar|platicar|hablemos|platiquemos)(?: mas)?(?: libremente| libre)?" +
        "|(?:termina|terminar|acaba|acabar|cierra|cerrar|deja|dejar|sal de|salir de|sal del|salir del|fin de|fin a|detener|deten|para|parar)(?: de)?(?: la| el| esta| este)? ?(?:charla|platica|conversacion|modo conversacion|modo charla|modo libre)" +
        "|vuelve (?:al )?modo normal|volver (?:al )?modo normal|modo (?:normal|comandos|ordenes)" +
        "|ya no uses tu $IAS|deja de usar tu $IAS|no uses tu $IAS|desactiva el modo conversacion)$")

    private val BYE = Regex("^(?:hasta luego|nos vemos|chao|adios|me voy|hasta manana|buenas noches)(?: genesis)?$")

    /** Hay charla libre activa (y no caducó por inactividad). */
    fun chatActive(): Boolean = chatOn && System.currentTimeMillis() < chatUntil

    /** Lo revisa el servicio cada pocos segundos: si la charla caducó por inactividad la cierra y devuelve el aviso hablado. */
    fun expiredNotice(): String? {
        if (chatOn && System.currentTimeMillis() >= chatUntil) {
            chatOn = false
            synchronized(hist) { hist.clear() }
            IA.keepOn(appCtx ?: return null, false)
            return "Me quedo en silencio para no molestarte. Dime Hola Génesis cuando quieras seguir."
        }
        return null
    }

    /** Entrar y salir del modo conversación. [s] ya viene normalizado. Devuelve null si no era para esto. */
    fun control(c: Context, s0: String, say: ((String) -> Unit)?): String? {
        val s = tidy(s0)
        if (ENTER.matches(s)) {
            if (chatOn) { chatUntil = System.currentTimeMillis() + CHAT_IDLE_MS; return "Ya estamos platicando, dime." }
            IA.unavailable(c)?.let { return notice("Para platicar libremente necesito mi IA interna. $it") }
            chatOn = true; chatUntil = System.currentTimeMillis() + CHAT_IDLE_MS
            synchronized(hist) { hist.clear() }
            IA.keepOn(c, true); appCtx = c.applicationContext
            return pick("Va, hablemos libremente. Ya no necesitas decir mi nombre; cuéntame, ¿cómo va tu día? Para salir di: terminar la charla.",
                "Listo, platiquemos como amigos. Te escucho, dime lo que quieras. Cuando quieras volver a las órdenes, di: terminar la charla.",
                "Perfecto, charlemos. Habla con calma, que ya estoy atento. Para salir, di: terminar la charla.")
        }
        if (EXIT.matches(s)) {
            if (!chatOn) return "Ya estoy en modo normal. Dime Hola Génesis y tu orden."
            endChat(c)
            return pick("Listo, volvemos al modo normal. Cuando quieras una orden, dime Hola Génesis.",
                "Hecho, termino la charla. Fue un gusto platicar; aquí sigo para tus órdenes.")
        }
        if (chatOn && BYE.matches(s)) {
            endChat(c)
            return pick("Hasta luego, cuídate mucho. Aquí estaré cuando quieras platicar.", "Nos vemos, que te vaya muy bien.")
        }
        return null
    }

    fun endChat(c: Context) {
        chatOn = false
        synchronized(hist) { hist.clear() }
        IA.keepOn(c, false)
    }

    /** Una vuelta de charla libre: contesta como persona, recordando lo último que dijeron. Se llama desde un hilo de fondo. */
    fun chat(c: Context, s: String, profile: String, say: ((String) -> Unit)?): String {
        chatUntil = System.currentTimeMillis() + CHAT_IDLE_MS
        IA.unavailable(c)?.let { endChat(c); return notice("$it Salgo del modo conversación.") }
        val sys = CHAT_SYS + (if (profile.isNotBlank()) " Lo que sabes de tu amigo: ${profile.take(160)}." else "")
        val turns = synchronized(hist) { hist.toList() }
        val a = IA.converse(c, sys, turns, s, say, 320)?.replace(Regex("[\\p{So}\\p{Cn}]"), "")?.trim()
        if (a == null || a.isBlank()) return notice(pick("Perdona, me quedé en blanco. ¿Me lo repites?", "Mmm, no me salió la respuesta. Dímelo otra vez."))
        synchronized(hist) { hist.addLast(s to a); while (hist.size > 4) hist.removeFirst() }
        chatUntil = System.currentTimeMillis() + CHAT_IDLE_MS
        return if (IA.streamed()) IA.tail() else a
    }
}
