package com.jarvis.assistant

/**
 * GenesisScript: el lenguaje en el que Génesis escribe código que SÍ puede ejecutar.
 *
 * Android no deja compilar ni ejecutar Kotlin dentro de una app instalada (y sería peligroso ejecutar código
 * generado con acceso al teléfono). Por eso Génesis ejecuta un lenguaje propio, pequeño y encerrado en una "caja":
 * solo hace cuentas, lógica, textos y decir cosas. NO puede llamar, mandar mensajes, tocar la pantalla, leer
 * archivos, usar internet ni borrar nada. Además corta solo si tarda más de 3 segundos o da demasiados pasos.
 *
 * Una instrucción por línea:
 *   x = 15 * 8 + 20                    asignar (números o textos entre comillas)
 *   funcion doble(a) = a * 2           función (el cuerpo es una expresión)
 *   di doble(x)                        decir / mostrar un resultado
 *   si x > 100 : di "grande"           condición en una línea
 *   repite 3 : di "hola"               repetir (máximo 100 veces)
 * Operadores: + - * / % ^  == != > < >= <=  y  o  no.  Textos: se unen con +.
 * Funciones incluidas: sumar, restar, multiplicar, dividir, potencia, porcentaje, interesCompuesto,
 * valorPorPunto, riesgoBeneficio, redondea, raiz, abs, max, min, largo, texto.
 * Comentarios: // o # al inicio de una línea.
 */
object GScript {
    class Result(val out: List<String>, val value: String?, val error: String?) {
        fun spoken(): String = when {
            error != null -> "Mi código dio un error: $error"
            out.isNotEmpty() -> out.joinToString(". ")
            value != null -> value
            else -> "Se ejecutó sin resultado."
        }
    }

    private class Err(msg: String) : Exception(msg)

    private class Cx(maxMs: Long) {
        val vars = HashMap<String, Any>()
        val funs = HashMap<String, Pair<List<String>, String>>()
        val out = ArrayList<String>()
        var steps = 0
        val deadline = System.currentTimeMillis() + maxMs
        fun tick() {
            if (++steps > 20000) throw Err("demasiados pasos")
            if ((steps and 255) == 0 && System.currentTimeMillis() > deadline) throw Err("tardó demasiado")
        }
    }

    /** Funciones que Génesis ya sabe, escritas en su propio lenguaje. */
    private val PRELUDE = """
        funcion sumar(a, b) = a + b
        funcion restar(a, b) = a - b
        funcion multiplicar(a, b) = a * b
        funcion dividir(a, b) = a / b
        funcion potencia(base, exponente) = base ^ exponente
        funcion porcentaje(pct, total) = total * pct / 100
        funcion interesCompuesto(capital, tasa, anios) = capital * (1 + tasa / 100) ^ anios
        funcion valorPorPunto(cuenta, riesgo, stop) = (cuenta * riesgo / 100) / stop
        funcion riesgoBeneficio(entrada, stop, objetivo) = abs(objetivo - entrada) / abs(entrada - stop)
    """.trimIndent()

    val FUNCTION_NAMES = mapOf(
        "sumar" to "sumar", "suma" to "sumar", "restar" to "restar", "resta" to "restar",
        "multiplicar" to "multiplicar", "multiplicacion" to "multiplicar", "dividir" to "dividir", "division" to "dividir",
        "potencia" to "potencia", "porcentaje" to "porcentaje", "interes compuesto" to "interesCompuesto",
        "tamano de posicion" to "valorPorPunto", "riesgo beneficio" to "riesgoBeneficio"
    )

    /** Ejecuta [code] en la caja segura. Nunca lanza excepciones. */
    fun run(code: String, maxMs: Long = 3000L): Result {
        val cx = Cx(maxMs)
        return try {
            if (code.length > 6000) throw Err("el código es demasiado largo")
            for (l in PRELUDE.lines()) line(l, cx, 0)
            var last: Any? = null
            val lines = code.lines()
            if (lines.size > 200) throw Err("demasiadas líneas")
            for (l in lines) line(l, cx, 0)?.let { last = it }
            Result(cx.out, last?.let { fmt(it) }, null)
        } catch (e: Err) {
            Result(cx.out, null, e.message ?: "error")
        } catch (e: StackOverflowError) {
            Result(cx.out, null, "demasiada recursión")
        } catch (e: Exception) {
            Result(cx.out, null, "no pude entender el código")
        }
    }

    /** Ejecuta una función ya conocida con números, p. ej. call("sumar", listOf(15.0, 8.0)). */
    fun call(fn: String, args: List<Double>): Result = run("di $fn(" + args.joinToString(", ") { fmt(it) } + ")")

    // ---------- Instrucciones ----------

    private val ID = "[\\p{L}_][\\p{L}\\p{N}_]*"
    private val reFun = Regex("^funci[oó]n\\s+($ID)\\s*\\(([^)]*)\\)\\s*=\\s*(.+)$")
    private val reIf = Regex("^si\\s+(.+?)\\s*:\\s*(.+)$")
    private val reRep = Regex("^repite\\s+(.+?)\\s*:\\s*(.+)$")
    private val reSay = Regex("^di\\s+(.+)$")
    private val reSet = Regex("^($ID)\\s*=(?!=)\\s*(.+)$")

    private fun line(raw: String, cx: Cx, depth: Int): Any? {
        cx.tick()
        if (depth > 3) throw Err("instrucciones demasiado anidadas")
        val t = raw.trim()
        if (t.isEmpty() || t.startsWith("//") || t.startsWith("#")) return null
        reFun.find(t)?.let { m ->
            val params = m.groupValues[2].split(",").map { it.trim() }.filter { it.isNotEmpty() }
            cx.funs[m.groupValues[1]] = params to m.groupValues[3]
            return null
        }
        reIf.find(t)?.let { m ->
            return if (truthy(eval(m.groupValues[1], cx, emptyMap(), 0))) line(m.groupValues[2], cx, depth + 1) else null
        }
        reRep.find(t)?.let { m ->
            val n = (eval(m.groupValues[1], cx, emptyMap(), 0) as? Double)?.toInt() ?: throw Err("repite necesita un número")
            if (n > 100) throw Err("no puedo repetir más de 100 veces")
            var last: Any? = null
            repeat(n) { line(m.groupValues[2], cx, depth + 1)?.let { last = it } }
            return last
        }
        reSay.find(t)?.let { m ->
            val v = eval(m.groupValues[1], cx, emptyMap(), 0)
            if (cx.out.size >= 50) throw Err("demasiadas salidas")
            cx.out.add(fmt(v)); return null
        }
        reSet.find(t)?.let { m ->
            val v = eval(m.groupValues[2], cx, emptyMap(), 0)
            if (cx.vars.size >= 200 && m.groupValues[1] !in cx.vars) throw Err("demasiadas variables")
            cx.vars[m.groupValues[1]] = v; return null
        }
        return eval(t, cx, emptyMap(), 0)
    }

    // ---------- Valores ----------

    private fun truthy(v: Any): Boolean = when (v) {
        is Boolean -> v
        is Double -> v != 0.0
        is String -> v.isNotEmpty()
        else -> false
    }

    fun fmt(v: Any): String = when (v) {
        is Boolean -> if (v) "verdadero" else "falso"
        is Double -> if (v == Math.floor(v) && Math.abs(v) < 1e12) v.toLong().toString()
                     else "%.4f".format(java.util.Locale.US, v).trimEnd('0').trimEnd('.')
        else -> v.toString()
    }

    private fun num(v: Any): Double = v as? Double ?: throw Err("esperaba un número y recibí «${fmt(v)}»")

    // ---------- Expresiones ----------

    private fun eval(text: String, cx: Cx, local: Map<String, Any>, depth: Int): Any = Parser(text, cx, local, depth).parseAll()

    private class Parser(val s: String, val cx: Cx, val local: Map<String, Any>, val depth: Int) {
        var i = 0

        fun ws() { while (i < s.length && s[i].isWhitespace()) i++ }
        fun peek(t: String): Boolean { ws(); return s.startsWith(t, i) }
        fun eat(t: String): Boolean { if (peek(t)) { i += t.length; return true }; return false }
        fun word(w: String): Boolean {
            ws()
            if (!s.startsWith(w, i)) return false
            val e = i + w.length
            if (e < s.length && (s[e].isLetterOrDigit() || s[e] == '_')) return false
            i = e; return true
        }

        fun parseAll(): Any {
            val v = or(); ws()
            if (i < s.length) throw Err("no entendí «${s.substring(i).take(20)}»")
            return v
        }

        fun or(): Any { var v = and(); while (eat("||") || word("o")) { val r = and(); v = truthy(v) || truthy(r) }; return v }
        fun and(): Any { var v = cmp(); while (eat("&&") || word("y")) { val r = cmp(); v = truthy(v) && truthy(r) }; return v }

        fun cmp(): Any {
            val l = add()
            for (op in listOf("==", "!=", ">=", "<=", ">", "<")) {
                if (eat(op)) {
                    val r = add()
                    if (op == "==") return fmt(l) == fmt(r)
                    if (op == "!=") return fmt(l) != fmt(r)
                    val a = num(l); val b = num(r)
                    return when (op) { ">=" -> a >= b; "<=" -> a <= b; ">" -> a > b; else -> a < b }
                }
            }
            return l
        }

        fun add(): Any {
            var v = mul()
            while (true) {
                ws()
                if (i < s.length && s[i] == '+') { i++; val r = mul(); v = if (v is String || r is String) fmt(v) + fmt(r) else num(v) + num(r) }
                else if (i < s.length && s[i] == '-') { i++; v = num(v) - num(mul()) }
                else return v
            }
        }

        fun mul(): Any {
            var v = pow()
            while (true) {
                ws()
                if (i < s.length && s[i] == '*') { i++; v = num(v) * num(pow()) }
                else if (i < s.length && s[i] == '/') { i++; val d = num(pow()); if (d == 0.0) throw Err("no se puede dividir entre cero"); v = num(v) / d }
                else if (i < s.length && s[i] == '%') { i++; val d = num(pow()); if (d == 0.0) throw Err("no se puede dividir entre cero"); v = num(v) % d }
                else return v
            }
        }

        fun pow(): Any {
            val b = unary()
            if (eat("^")) {
                val e = num(pow())
                if (Math.abs(e) > 1000) throw Err("exponente demasiado grande")
                val r = Math.pow(num(b), e)
                if (r.isNaN() || r.isInfinite()) throw Err("resultado fuera de rango")
                return r
            }
            return b
        }

        fun unary(): Any {
            ws()
            if (i < s.length && s[i] == '-') { i++; return -num(unary()) }
            if (word("no") || (i < s.length && s[i] == '!' && !s.startsWith("!=", i) && (++i > 0))) return !truthy(unary())
            return primary()
        }

        fun primary(): Any {
            cx.tick(); ws()
            if (i >= s.length) throw Err("falta algo al final")
            val c = s[i]
            if (c == '(') { i++; val v = or(); if (!eat(")")) throw Err("falta cerrar el paréntesis"); return v }
            if (c == '"') {
                val sb = StringBuilder(); i++
                while (i < s.length && s[i] != '"') sb.append(s[i++])
                if (i >= s.length) throw Err("falta cerrar las comillas")
                i++; return sb.toString()
            }
            if (c.isDigit() || (c == '.' && i + 1 < s.length && s[i + 1].isDigit())) {
                val st = i
                while (i < s.length && (s[i].isDigit() || s[i] == '.')) i++
                return s.substring(st, i).toDoubleOrNull() ?: throw Err("número mal escrito")
            }
            if (c.isLetter() || c == '_') {
                val st = i
                while (i < s.length && (s[i].isLetterOrDigit() || s[i] == '_')) i++
                val name = s.substring(st, i)
                ws()
                if (i < s.length && s[i] == '(') {
                    i++
                    val args = ArrayList<Any>()
                    ws()
                    if (!eat(")")) {
                        do { args.add(or()) } while (eat(","))
                        if (!eat(")")) throw Err("falta cerrar el paréntesis de $name")
                    }
                    return callFn(name, args)
                }
                return when (name) {
                    "verdadero" -> true
                    "falso" -> false
                    "pi" -> Math.PI
                    else -> local[name] ?: cx.vars[name] ?: throw Err("no conozco «$name»")
                }
            }
            throw Err("no entendí «${s.substring(i).take(20)}»")
        }

        fun callFn(name: String, a: List<Any>): Any {
            cx.tick()
            cx.funs[name]?.let { (params, body) ->
                if (a.size != params.size) throw Err("$name necesita ${params.size} valores")
                if (depth >= 25) throw Err("demasiada recursión")
                return Parser(body, cx, params.zip(a).toMap(), depth + 1).parseAll()
            }
            fun n(k: Int): Double { if (a.size <= k) throw Err("$name necesita más valores"); return num(a[k]) }
            return when (name) {
                "redondea" -> Math.round(n(0)).toDouble()
                "raiz" -> { if (n(0) < 0) throw Err("no hay raíz de un número negativo"); Math.sqrt(n(0)) }
                "abs" -> Math.abs(n(0))
                "max" -> Math.max(n(0), n(1))
                "min" -> Math.min(n(0), n(1))
                "largo" -> (if (a.isEmpty()) 0 else fmt(a[0]).length).toDouble()
                "texto" -> if (a.isEmpty()) "" else fmt(a[0])
                else -> throw Err("no conozco la función «$name»")
            }
        }
    }
}
