package com.jarvis.assistant

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.graphics.Typeface
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.sin

/**
 * Capa FUTURISTA del HUD de Génesis (se dibuja alrededor y detrás del reactor):
 *  - lluvia de datos cayendo por la pantalla y una banda de escaneo holográfico que sube
 *  - radar: haz giratorio con estela dentro del aro
 *  - 3 órbitas atómicas inclinadas con electrones
 *  - 2 hexágonos contrarrotantes con nodos y un pulso de energía que recorre el perímetro
 *  - anillo de código hexadecimal girando alrededor
 *  - anillo de ecualizador (90 barras) que reacciona a tu voz al escuchar
 *  - ondas de energía que salen del núcleo
 *  - esquinas de mira, reglas laterales con marcador y telemetría en vivo (hora real)
 * Todo se calcula sin crear objetos por cuadro, para que vaya fluido.
 */
class Futuro {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val tx = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.MONOSPACE }
    private val rect = RectF()
    private val path = Path()
    private val pt = FloatArray(2)
    private val rnd = java.util.Random(21)
    private val code: String = (0 until 70).joinToString("   ") { String.format(Locale.US, "%02X", rnd.nextInt(256)) }

    // lluvia de datos
    private val sx = FloatArray(14) { rnd.nextFloat() }
    private val ss = FloatArray(14) { 0.5f + rnd.nextFloat() }

    // shaders cacheados por color
    private var shaderColor = 0
    private var sweep: SweepGradient? = null
    private var band: LinearGradient? = null

    // el haz del radar acumula ángulo (no depende de la velocidad actual → no da saltos al cambiar de estado)
    private var lastT = 0L
    private var sweepAng = 0f

    // reloj real, recalculado una vez por segundo
    private val fmt = SimpleDateFormat("HH:mm:ss", Locale.US)
    private val date = Date()
    private var lastSec = -1L
    private var timeStr = ""

    private fun shaders(color: Int) {
        if (shaderColor == color && sweep != null) return
        shaderColor = color
        sweep = SweepGradient(0f, 0f, intArrayOf(Color.TRANSPARENT, withA(color, 0f), withA(color, 0.34f)), floatArrayOf(0f, 0.78f, 1f))
        band = LinearGradient(0f, -90f, 0f, 90f, intArrayOf(Color.TRANSPARENT, withA(color, 0.16f), Color.TRANSPARENT),
            floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
    }

    /** Capa de FONDO: lluvia de datos, banda de escaneo y radar. Se dibuja antes que los aros. */
    fun under(cv: Canvas, w: Float, h: Float, cx: Float, cy: Float, r: Float, color: Int, now: Long, thinking: Boolean) {
        shaders(color)
        val dt = (now - lastT).coerceIn(0L, 100L); lastT = now
        sweepAng = (sweepAng + dt * (if (thinking) 0.42f else 0.17f)) % 360f

        // lluvia de datos
        p.style = Paint.Style.STROKE; p.strokeWidth = 3f; p.strokeCap = Paint.Cap.ROUND
        for (i in sx.indices) {
            val x = sx[i] * w
            for (j in 0 until 6) {
                val f = (j / 6f + now * 0.00007f * ss[i]) % 1f
                p.color = withA(color, 0.20f * sin(PI.toFloat() * f))
                cv.drawLine(x, f * h, x, f * h + 12f + 26f * ss[i], p)
            }
        }
        p.strokeCap = Paint.Cap.BUTT

        // banda de escaneo holográfico (sube por la pantalla)
        val y = (h + 180f) - ((now * 0.09f) % (h + 360f))
        cv.save(); cv.translate(0f, y)
        p.style = Paint.Style.FILL; p.shader = band
        cv.drawRect(0f, -90f, w, 90f, p)
        p.shader = null
        cv.restore()

        // radar: haz con estela
        cv.save(); cv.translate(cx, cy); cv.rotate(sweepAng)
        p.style = Paint.Style.FILL; p.shader = sweep
        cv.drawCircle(0f, 0f, r * 0.74f, p)
        p.shader = null
        p.style = Paint.Style.STROKE; p.strokeWidth = 3f; p.color = withA(color, 0.75f)
        cv.drawLine(0f, 0f, r * 0.74f, 0f, p)
        cv.restore()
    }

    private fun hexPt(cx: Float, cy: Float, rr: Float, deg: Float, i: Int) {
        val a = Math.toRadians((deg + i * 60f).toDouble())
        pt[0] = cx + (cos(a) * rr).toFloat(); pt[1] = cy + (sin(a) * rr).toFloat()
    }

    private fun hex(cv: Canvas, cx: Float, cy: Float, rr: Float, deg: Float, col: Int, sw: Float) {
        path.reset()
        for (i in 0..6) {
            hexPt(cx, cy, rr, deg, i)
            if (i == 0) path.moveTo(pt[0], pt[1]) else path.lineTo(pt[0], pt[1])
        }
        p.style = Paint.Style.STROKE; p.strokeWidth = sw; p.color = col
        cv.drawPath(path, p)
    }

    /** Capa de FRENTE: ondas, órbitas, hexágonos, código, ecualizador y marcos del HUD. Se dibuja sobre los aros. */
    fun over(cv: Canvas, w: Float, h: Float, cx: Float, cy: Float, r: Float, color: Int, now: Long,
             listening: Boolean, thinking: Boolean, glow: Float) {
        val light = lighten(color, 0.55f)

        // ondas de energía que salen del núcleo
        p.style = Paint.Style.STROKE; p.strokeWidth = 2.5f
        val waves = if (listening || thinking) 3 else 1
        for (k in 0 until waves) {
            val f = ((now + k * 700L) % 2100L) / 2100f
            p.color = withA(color, (1f - f) * (if (listening) 0.55f else 0.25f))
            cv.drawCircle(cx, cy, r * (0.5f + 0.8f * f), p)
        }

        // 3 órbitas atómicas inclinadas con electrones
        val oa = r * 0.92f; val ob = r * 0.30f
        for (k in 0 until 3) {
            val rot = k * 60f + now * 0.012f * (1f + k * 0.4f) * (if (k == 1) -1f else 1f)
            cv.save(); cv.translate(cx, cy); cv.rotate(rot)
            rect.set(-oa, -ob, oa, ob)
            p.style = Paint.Style.STROKE; p.strokeWidth = 2f; p.color = withA(color, 0.30f)
            cv.drawOval(rect, p)
            val e = now * 0.0021f * (1f + k * 0.3f) + k * 2.1f
            val ex = cos(e) * oa; val ey = sin(e) * ob
            p.style = Paint.Style.FILL
            p.color = withA(color, 0.35f); cv.drawCircle(ex, ey, 15f, p)
            p.color = withA(Color.WHITE, 0.95f); cv.drawCircle(ex, ey, 7f, p)
            cv.restore()
        }

        // hexágonos contrarrotantes + nodos + pulso viajero
        val hd = now * 0.006f
        val hr = r * 1.115f
        hex(cv, cx, cy, hr, hd, withA(light, 0.6f), 3f)
        hex(cv, cx, cy, r * 1.155f, -now * 0.004f + 30f, withA(color, 0.35f), 1.5f)
        p.style = Paint.Style.FILL; p.color = withA(light, 0.95f)
        for (i in 0 until 6) { hexPt(cx, cy, hr, hd, i); cv.drawCircle(pt[0], pt[1], 6f, p) }
        val tt = ((now % 3000L) / 3000f) * 6f
        val seg = floor(tt).toInt(); val fr = tt - seg
        hexPt(cx, cy, hr, hd, seg); val x0 = pt[0]; val y0 = pt[1]
        hexPt(cx, cy, hr, hd, seg + 1)
        val px = x0 + (pt[0] - x0) * fr; val py = y0 + (pt[1] - y0) * fr
        p.color = withA(color, 0.35f); cv.drawCircle(px, py, 20f, p)
        p.color = withA(Color.WHITE, 0.95f); cv.drawCircle(px, py, 8f, p)

        // anillo de código hexadecimal girando
        tx.textSize = r * 0.042f; tx.color = withA(color, 0.5f)
        val rr = r * 1.2f
        path.reset(); path.addCircle(cx, cy, rr, Path.Direction.CW)
        val circ = (2.0 * PI * rr).toFloat()
        val off = (now * 0.04f) % circ
        cv.drawTextOnPath(code, path, off, 4f, tx)
        cv.drawTextOnPath(code, path, off - circ, 4f, tx)

        // ecualizador circular (reacciona a la voz)
        val wr = r * 0.575f
        p.style = Paint.Style.STROKE; p.strokeWidth = 4f; p.strokeCap = Paint.Cap.ROUND
        p.color = withA(light, if (listening) 0.95f else 0.55f)
        val bars = 90
        for (i in 0 until bars) {
            val a = Math.toRadians(i * 360.0 / bars - 90.0)
            val wob = 0.5f + 0.5f * sin(i * 0.9f + now * 0.006f) * sin(i * 0.37f - now * 0.0033f)
            val amp = if (listening) 6f + (0.25f + 0.75f * glow) * 30f * wob else if (thinking) 4f + 10f * wob else 3f + 4f * wob
            val ca = cos(a).toFloat(); val sa = sin(a).toFloat()
            cv.drawLine(cx + ca * wr, cy + sa * wr, cx + ca * (wr + amp), cy + sa * (wr + amp), p)
        }
        p.strokeCap = Paint.Cap.BUTT

        // esquinas de mira (la esquina de arriba a la derecha queda libre para el reactor del menú)
        val m = 40f; val len = 90f
        p.strokeWidth = 5f; p.color = withA(light, 0.8f)
        cv.drawLine(m, m + len, m, m, p); cv.drawLine(m, m, m + len, m, p)
        cv.drawLine(m, h - m - len, m, h - m, p); cv.drawLine(m, h - m, m + len, h - m, p)
        cv.drawLine(w - m, h - m - len, w - m, h - m, p); cv.drawLine(w - m, h - m, w - m - len, h - m, p)

        // reglas laterales con marcador
        val y0r = h * 0.26f; val y1r = h * 0.74f
        p.strokeWidth = 2f; p.color = withA(color, 0.35f)
        var yy = y0r; var n = 0
        while (yy <= y1r) {
            val l = if (n % 5 == 0) 28f else 14f
            cv.drawLine(22f, yy, 22f + l, yy, p)
            cv.drawLine(w - 22f, yy, w - 22f - l, yy, p)
            yy += 28f; n++
        }
        val mkL = y0r + (y1r - y0r) * (0.5f + 0.5f * sin(now * 0.0008f))
        val mkR = y0r + (y1r - y0r) * (0.5f + 0.5f * sin(now * 0.0011f + 2f))
        p.style = Paint.Style.FILL; p.color = withA(light, 0.95f)
        path.reset(); path.moveTo(64f, mkL); path.lineTo(46f, mkL - 11f); path.lineTo(46f, mkL + 11f); path.close(); cv.drawPath(path, p)
        path.reset(); path.moveTo(w - 64f, mkR); path.lineTo(w - 46f, mkR - 11f); path.lineTo(w - 46f, mkR + 11f); path.close(); cv.drawPath(path, p)

        // telemetría (la hora es la real)
        val sec = System.currentTimeMillis() / 1000L
        if (sec != lastSec) { lastSec = sec; date.time = sec * 1000L; timeStr = fmt.format(date) }
        tx.textSize = 26f; tx.color = withA(light, 0.9f)
        val tx0 = m + 8f; val ty0 = m + len + 52f
        val blink = if ((now / 500L) % 2L == 0L) 1f else 0.25f
        p.color = withA(color, blink); cv.drawCircle(tx0 + 8f, ty0 - 9f, 7f, p)
        cv.drawText("SISTEMA // EN LÍNEA", tx0 + 28f, ty0, tx)
        cv.drawText(timeStr, tx0 + 28f, ty0 + 36f, tx)
        cv.drawText("ENLACE // " + (if (listening) "ESCUCHANDO" else if (thinking) "PROCESANDO" else "EN ESPERA"), tx0 + 28f, ty0 + 72f, tx)

        p.style = Paint.Style.STROKE
    }
}
