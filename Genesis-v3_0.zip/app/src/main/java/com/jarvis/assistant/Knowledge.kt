package com.jarvis.assistant

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import androidx.work.Constraints
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.Normalizer
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

object Net {
    fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")

    fun get(url: String, ms: Int = 5000): String? =
        Web.fetch(url, ms, ua = "GenesisAssistant/1.4 (asistente personal Android)")

    fun online(ctx: Context): Boolean = try {
        val cm = ctx.getSystemService(ConnectivityManager::class.java)
        cm.getNetworkCapabilities(cm.activeNetwork)?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true
    } catch (_: Exception) { false }

    /** Recorta en el último punto antes de [max] para que se lea bien en voz alta. */
    fun sentences(t: String, max: Int = 380): String {
        val s = t.replace(Regex("\\s+"), " ").trim()
        if (s.length <= max) return s
        val cut = s.lastIndexOf(". ", max)
        return if (cut > 80) s.substring(0, cut + 1) else s.substring(0, max).trimEnd() + "…"
    }
}

/**
 * Búsqueda rápida en internet cuando Génesis no sabe algo: lanza tres fuentes a la vez
 * (resumen de Wikipedia, DuckDuckGo y búsqueda de texto en Wikipedia), espera como máximo [timeoutMs]
 * y guarda lo que encuentre en su memoria para contestar la próxima vez sin internet.
 */
object WebLookup {
    private val pool = Executors.newFixedThreadPool(4)
    private val lead = Regex("^(que|quien|quienes|cual|cuales|cuando|donde|como|cuanto|cuantos|cuantas|por que)( es| son| fue| fueron| significa| se llama| se hace| se escribe| hay| mide| pesa)?( el| la| los| las| un| una)? ")

    fun clean(q: String): String = Brain.norm(q).replace(lead, "").replace(Regex("[?¿!¡]"), "").trim()

    private fun decode(s: String) = s.replace(Regex("<[^>]+>"), "").replace("&quot;", "\"").replace("&amp;", "&")
        .replace("&#039;", "'").replace("&nbsp;", " ")

    private fun wikiTitle(q: String, lang: String = "es"): String? {
        val r = Net.get("https://$lang.wikipedia.org/w/api.php?action=opensearch&limit=1&format=json&search=" + Net.enc(q)) ?: return null
        return try { JSONArray(r).getJSONArray(1).optString(0).ifBlank { null } } catch (_: Exception) { null }
    }

    fun wikiSummary(title: String, lang: String = "es"): String? {
        val r = Net.get("https://$lang.wikipedia.org/api/rest_v1/page/summary/" + Net.enc(title.replace(" ", "_")).replace("+", "%20")) ?: return null
        return try {
            val o = JSONObject(r)
            if (o.optString("type") == "disambiguation") null else o.optString("extract").ifBlank { null }
        } catch (_: Exception) { null }
    }

    private fun fromWikipedia(q: String): Pair<String, String>? {
        val t = wikiTitle(q) ?: return null
        val x = wikiSummary(t) ?: return null
        return t to x
    }

    private fun fromDuck(q: String): Pair<String, String>? {
        val r = Net.get("https://api.duckduckgo.com/?format=json&no_html=1&skip_disambig=1&kl=es-es&q=" + Net.enc(q)) ?: return null
        return try {
            val o = JSONObject(r)
            val txt = o.optString("AbstractText").ifBlank { o.optString("Answer") }
                .ifBlank { o.optJSONArray("RelatedTopics")?.optJSONObject(0)?.optString("Text") ?: "" }
            if (txt.length < 30) null else o.optString("Heading").ifBlank { q } to txt
        } catch (_: Exception) { null }
    }

    private fun fromSnippet(q: String): Pair<String, String>? {
        val r = Net.get("https://es.wikipedia.org/w/api.php?action=query&list=search&srlimit=1&format=json&srsearch=" + Net.enc(q)) ?: return null
        return try {
            val h = JSONObject(r).getJSONObject("query").getJSONArray("search").getJSONObject(0)
            val sn = decode(h.getString("snippet"))
            if (sn.length < 40) null else h.getString("title") to (h.getString("title") + ": " + sn + "…")
        } catch (_: Exception) { null }
    }

    /** Devuelve el texto hablado o null si no halló nada a tiempo. Lo encontrado queda guardado en la memoria. */
    fun answer(ctx: Context, brain: Brain, question: String, timeoutMs: Long = 5000): String? {
        if (!Net.online(ctx)) return null
        val q = clean(question).ifBlank { return null }
        val jobs = listOf(pool.submit<Pair<String, String>?> { fromWikipedia(q) },
            pool.submit<Pair<String, String>?> { fromDuck(q) },
            pool.submit<Pair<String, String>?> { fromSnippet(q) })
        val deadline = System.currentTimeMillis() + timeoutMs
        try {
            for (j in jobs) {
                val left = deadline - System.currentTimeMillis()
                if (left <= 0) break
                val r = try { j.get(left, TimeUnit.MILLISECONDS) } catch (_: Exception) { null }
                if (r != null) {
                    brain.teach(question.trim() + " — " + r.first, r.second)   // queda en su base de datos
                    return Net.sentences(r.second)
                }
            }
        } finally { jobs.forEach { it.cancel(true) } }
        return null
    }
}

/** Aprende de cualquier palabra o tema que le escribas o le digas: Wikipedia (es, y en como respaldo) y el diccionario. */
object Learner {
    private fun titles(term: String, limit: Int, lang: String): List<String> {
        val r = Net.get("https://$lang.wikipedia.org/w/api.php?action=opensearch&limit=$limit&format=json&search=" + Net.enc(term), 6000) ?: return emptyList()
        return try { val a = JSONArray(r).getJSONArray(1); (0 until a.length()).map { a.getString(it) } } catch (_: Exception) { emptyList() }
    }

    /** Devuelve cuántos datos nuevos aprendió sobre [term]. */
    fun topic(ctx: Context, brain: Brain, term: String): Int {
        val t = term.trim(); if (t.isEmpty()) return 0
        val got = mutableListOf<Pair<String, String>>()
        for (title in titles(t, 5, "es")) {
            WebLookup.wikiSummary(title)?.let { got.add(title to it) }
            Thread.sleep(120)
        }
        if (got.isEmpty()) for (title in titles(t, 3, "en")) {
            WebLookup.wikiSummary(title, "en")?.let { got.add("$title (en)" to it) }
            Thread.sleep(120)
        }
        var n = brain.teachMany(got)
        if (!t.contains(" ") && Vocab.lookup(ctx, t) != null) n++        // palabra suelta: también su definición
        return n
    }

    fun many(ctx: Context, brain: Brain, text: String, progress: ((String) -> Unit)? = null): Int {
        var total = 0
        text.split(Regex("[,;\\n]+")).map { it.trim() }.filter { it.isNotEmpty() }.forEach { t ->
            progress?.invoke(t); total += topic(ctx, brain, t)
        }
        return total
    }
}

/**
 * Diccionario del idioma en una base de datos SQLite aparte de la memoria (para que pueda crecer mucho sin
 * volver lenta la memoria normal). Se llena en segundo plano con las entradas del Wiktionario en español.
 */
object Vocab {
    private class Db(c: Context) : SQLiteOpenHelper(c, "vocab.db", null, 1) {
        override fun onCreate(db: SQLiteDatabase) {
            db.execSQL("CREATE TABLE w(word TEXT PRIMARY KEY, plain TEXT, def TEXT NOT NULL)")
            db.execSQL("CREATE INDEX w_plain ON w(plain)")
        }
        override fun onUpgrade(db: SQLiteDatabase, o: Int, n: Int) {}
    }
    @Volatile private var db: Db? = null
    private fun d(c: Context): Db = db ?: synchronized(this) { db ?: Db(c.applicationContext).also { db = it } }
    private fun plain(s: String) = Normalizer.normalize(s.lowercase(), Normalizer.Form.NFD).replace(Regex("\\p{M}+"), "")

    fun count(c: Context): Int = try {
        d(c).readableDatabase.rawQuery("SELECT COUNT(*) FROM w", null).use { if (it.moveToFirst()) it.getInt(0) else 0 }
    } catch (_: Exception) { 0 }

    fun local(c: Context, word: String): String? = try {
        val w = word.trim().lowercase()
        d(c).readableDatabase.rawQuery("SELECT def FROM w WHERE word=? OR plain=? ORDER BY (word=?) DESC LIMIT 1", arrayOf(w, plain(w), w))
            .use { if (it.moveToFirst()) it.getString(0) else null }
    } catch (_: Exception) { null }

    fun store(c: Context, items: List<Pair<String, String>>) {
        if (items.isEmpty()) return
        val db = d(c).writableDatabase
        db.beginTransaction()
        try {
            items.forEach { (w, def) ->
                val v = ContentValues().apply { put("word", w.lowercase()); put("plain", plain(w)); put("def", def) }
                db.insertWithOnConflict("w", null, v, SQLiteDatabase.CONFLICT_REPLACE)
            }
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    fun wipe(c: Context) = synchronized(this) {
        try { db?.close() } catch (_: Exception) {}
        db = null; c.deleteDatabase("vocab.db")
        Prefs.setVocabCursor(c, ""); Prefs.setVocabDone(c, false)
    }

    /** Local primero; si no está y hay internet, la busca en el Wiktionario y la guarda. */
    fun lookup(c: Context, word: String): String? {
        local(c, word)?.let { return it }
        if (!Net.online(c)) return null
        val got = fetch(listOf(word.trim().lowercase()))
        store(c, got)
        return got.firstOrNull()?.second
    }

    private fun strip(s: String): String {
        var t = s
        repeat(3) { t = t.replace(Regex("\\{\\{[^{}]*\\}\\}"), "") }
        t = t.replace(Regex("\\[\\[(?:[^\\]|]*\\|)?([^\\]]*)\\]\\]"), "$1").replace("'''", "").replace("''", "")
            .replace(Regex("<[^>]+>"), "").replace(Regex("\\s+"), " ")
        return t.trim().trim(':', ';', ' ')
    }

    /** Lee el wikitexto de hasta 50 palabras a la vez y se queda con la sección en español. */
    fun fetch(words: List<String>): List<Pair<String, String>> {
        if (words.isEmpty()) return emptyList()
        val r = Net.get("https://es.wiktionary.org/w/api.php?action=query&prop=revisions&rvprop=content&rvslots=main&redirects=1&format=json&titles=" +
            Net.enc(words.take(50).joinToString("|")), 12000) ?: return emptyList()
        val out = mutableListOf<Pair<String, String>>()
        try {
            val pages = JSONObject(r).getJSONObject("query").getJSONObject("pages")
            pages.keys().forEach { k ->
                val p = pages.getJSONObject(k)
                val title = p.optString("title")
                val text = p.optJSONArray("revisions")?.optJSONObject(0)?.optJSONObject("slots")?.optJSONObject("main")?.optString("*")
                    ?: p.optJSONArray("revisions")?.optJSONObject(0)?.optJSONObject("slots")?.optJSONObject("main")?.optString("content")
                if (title.isNotEmpty() && !text.isNullOrEmpty()) parse(title, text)?.let { out.add(title to it) }
            }
        } catch (_: Exception) {}
        return out
    }

    private fun parse(title: String, text: String): String? {
        val st = Regex("==\\s*\\{\\{lengua\\|es\\}\\}\\s*==").find(text) ?: return null
        var sec = text.substring(st.range.last + 1)
        Regex("\\n==\\s*\\{\\{lengua\\|").find(sec)?.let { sec = sec.substring(0, it.range.first) }
        var pos = ""
        val defs = mutableListOf<String>()
        for (line in sec.lines()) {
            Regex("^===\\s*\\{\\{([^|}]+)\\|es").find(line)?.let { pos = it.groupValues[1].trim() }
            Regex("^;\\s*(\\d+)[^:]*:\\s*(.+)$").find(line)?.let { m ->
                val d = strip(m.groupValues[2]); if (d.length > 3 && defs.size < 4) defs.add(m.groupValues[1] + ". " + d)
            }
        }
        if (defs.isEmpty()) return null
        return title + (if (pos.isNotEmpty()) ", $pos" else "") + ": " + defs.joinToString(" ")
    }

    private val goodWord = Regex("^[a-zñáéíóúü]{3,18}$")

    /** Toma las siguientes ~50 entradas del Wiktionario, en orden alfabético, y guarda sus definiciones. Devuelve -1 si ya terminó. */
    fun step(c: Context): Int {
        val cur = Prefs.vocabCursor(c)
        val r = Net.get("https://es.wiktionary.org/w/api.php?action=query&list=allpages&apnamespace=0&apfilterredir=nonredirects&aplimit=50&format=json" +
            (if (cur.isNotEmpty()) "&apcontinue=" + Net.enc(cur) else ""), 10000) ?: return 0
        return try {
            val o = JSONObject(r)
            val a = o.getJSONObject("query").getJSONArray("allpages")
            val words = (0 until a.length()).map { a.getJSONObject(it).getString("title") }.filter { goodWord.matches(it) }
            store(c, fetch(words))
            val next = o.optJSONObject("continue")?.optString("apcontinue").orEmpty()
            if (next.isEmpty()) { Prefs.setVocabDone(c, true); -1 } else { Prefs.setVocabCursor(c, next); words.size }
        } catch (_: Exception) { 0 }
    }

    fun start(c: Context) {
        Prefs.setVocabOn(c, true)
        val req = OneTimeWorkRequestBuilder<VocabWorker>()
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).setRequiresBatteryNotLow(true).build()).build()
        WorkManager.getInstance(c).enqueueUniqueWork("genesis-vocab", ExistingWorkPolicy.KEEP, req)
    }

    fun stop(c: Context) { Prefs.setVocabOn(c, false); WorkManager.getInstance(c).cancelUniqueWork("genesis-vocab") }

    class VocabWorker(c: Context, p: WorkerParameters) : Worker(c, p) {
        override fun doWork(): Result {
            val c = applicationContext
            val end = System.currentTimeMillis() + 8 * 60 * 1000L          // tandas de 8 minutos (límite de Android: 10)
            var finished = false; var failures = 0
            while (System.currentTimeMillis() < end && Prefs.vocabOn(c) && !isStopped) {
                if (CloudArchive.critical(c)) break                           // poco espacio: se pausa
                val n = Vocab.step(c)
                if (n < 0) { finished = true; break }
                if (n == 0 && ++failures >= 5) break
                Thread.sleep(500)
            }
            if (Prefs.vocabOn(c) && !finished) {
                val next = OneTimeWorkRequestBuilder<VocabWorker>().setInitialDelay(2, TimeUnit.MINUTES)
                    .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).setRequiresBatteryNotLow(true).build()).build()
                WorkManager.getInstance(c).enqueueUniqueWork("genesis-vocab", ExistingWorkPolicy.REPLACE, next)
            }
            return Result.success()
        }
    }
}
