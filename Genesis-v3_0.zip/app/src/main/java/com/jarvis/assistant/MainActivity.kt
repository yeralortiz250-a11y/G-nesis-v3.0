package com.jarvis.assistant

import android.Manifest
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.WindowManager
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var hud: HudView
    private lateinit var core: CoreButton
    private lateinit var menu: RadialMenuView
    private lateinit var mic: MicButton
    private val sessionListener = android.content.SharedPreferences.OnSharedPreferenceChangeListener { _, k ->
        if (k == "session_on") runOnUiThread { mic.active = Prefs.sessionOn(this) }
    }
    private lateinit var brain: Brain

    private val pickCloud = registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            contentResolver.takePersistableUriPermission(uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            Prefs.setTree(this, uri.toString())
            Toast.makeText(this, "Nube conectada. Génesis archivará allí cuando el celular se llene.", Toast.LENGTH_LONG).show()
        }
    }

    private val perms = arrayOf(
        Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE, Manifest.permission.SEND_SMS,
        Manifest.permission.READ_CONTACTS, Manifest.permission.CAMERA, Manifest.permission.POST_NOTIFICATIONS,
        Manifest.permission.READ_CALENDAR, Manifest.permission.WRITE_CALENDAR, Manifest.permission.ACCESS_COARSE_LOCATION,
        Manifest.permission.READ_PHONE_STATE, Manifest.permission.READ_CALL_LOG, Manifest.permission.ANSWER_PHONE_CALLS
    )

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        // PANTALLA COMPLETA de verdad: se dibuja bajo la barra de notificaciones y la de navegación (sin franjas negras)
        androidx.core.view.WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        if (Build.VERSION.SDK_INT >= 28)
            window.attributes = window.attributes.apply { layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES }
        brain = Brain(this)
        AutoLearner.schedule(this)   // aprendizaje autónomo en segundo plano
        val d = resources.displayMetrics.density
        val root = FrameLayout(this)

        hud = HudView(this); root.addView(hud)

        core = CoreButton(this).apply { alpha = 0f; visibility = android.view.View.INVISIBLE }
        val coreSize = (100 * d).toInt()      // botón del menú (antes 76)
        val micSize = (72 * d).toInt()        // vista del micrófono: el círculo mide 56 dp, igual que el sticker del reloj
        root.addView(core, FrameLayout.LayoutParams(coreSize, coreSize, Gravity.TOP or Gravity.END).apply {
            setMargins(0, (28 * d).toInt(), (10 * d).toInt(), 0)
        })

        mic = MicButton(this).apply {
            alpha = 0f; visibility = android.view.View.INVISIBLE
            contentDescription = "Micrófono: toca para comenzar sesión, mantén presionado para terminarla"
            active = Prefs.sessionOn(this@MainActivity)
        }
        root.addView(mic, FrameLayout.LayoutParams(micSize, micSize, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply {
            setMargins(0, 0, 0, (36 * d).toInt())      // centro a ~72 dp del borde: donde estaba el sticker del reloj
        })
        mic.setOnClickListener {
            Sfx.tap()
            val wasOn = Prefs.sessionOn(this) && JarvisService.instance != null
            JarvisService.begin(this)          // si ya estaba activa, solo calla a Génesis
            if (!wasOn) Toast.makeText(this, "Sesión iniciada, sistemas listos", Toast.LENGTH_SHORT).show()
        }
        mic.setOnLongClickListener {
            JarvisService.end()
            Toast.makeText(this, "Sesión terminada", Toast.LENGTH_SHORT).show(); true
        }

        menu = RadialMenuView(this).apply {
            items = listOf(
                RadialMenuView.Item("♪", "Voz"), RadialMenuView.Item("+", "Comando"),
                RadialMenuView.Item("◐", "Color"), RadialMenuView.Item("⌘", "Accesibilidad"),
                RadialMenuView.Item("⇩", "Aprender"), RadialMenuView.Item("AI", "Clave IA"),
                RadialMenuView.Item("✕", "Borrar"), RadialMenuView.Item("☁", "Nube"), RadialMenuView.Item("PIN", "Desbloqueo"),
                RadialMenuView.Item("◉", "Cerebro"), RadialMenuView.Item("◌", "Burbuja"), RadialMenuView.Item("IA", "Cerebro IA")
            )
            onPick = { i -> close { action(i) } }
        }
        root.addView(menu, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)
        // Con la barra de estado oculta, el botón del menú sube; si hay "notch"/cámara se respeta su alto
        androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(root) { _, ins ->
            val bars = ins.getInsets(androidx.core.view.WindowInsetsCompat.Type.systemBars() or androidx.core.view.WindowInsetsCompat.Type.displayCutout())
            (core.layoutParams as FrameLayout.LayoutParams).topMargin = bars.top + (20 * d).toInt()
            core.requestLayout()
            ins
        }
        immersive()

        // Tocar para iniciar
        hud.onStartTap = {
            Sfx.boot()
            hud.beginBoot()
            requestPermissions(perms, 1)
        }
        hud.onBootDone = {
            runOnUiThread {
                core.visibility = android.view.View.VISIBLE
                core.scaleX = 0.2f; core.scaleY = 0.2f
                core.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(700).start()
                mic.visibility = android.view.View.VISIBLE
                mic.animate().alpha(1f).setDuration(700).start()
                startJarvis()
            }
        }
        core.setOnClickListener { Sfx.tap(); menu.open() }
    }

    private fun startJarvis() {
        if (hud.phase == 2 && ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == 0)
            ContextCompat.startForegroundService(this, Intent(this, JarvisService::class.java))
        if (hud.phase == 2 && JarvisAccessibilityService.instance == null)
            Toast.makeText(this, "Activa Accesibilidad > Génesis para que pueda controlar el celular", Toast.LENGTH_LONG).show()
    }

    /** Oculta barra de notificaciones y de navegación (aparecen un instante si deslizas desde el borde). */
    private fun immersive() {
        val c = androidx.core.view.WindowInsetsControllerCompat(window, window.decorView)
        c.systemBarsBehavior = androidx.core.view.WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        c.hide(androidx.core.view.WindowInsetsCompat.Type.systemBars())
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) immersive()
    }

    override fun onResume() {
        super.onResume(); immersive(); Bubble.appVisible = true; Bubble.sync(this)     // dentro de la app la burbuja se esconde
        hud.color = Prefs.color(this); startJarvis()
        mic.active = Prefs.sessionOn(this)
        getSharedPreferences("jarvis", MODE_PRIVATE).registerOnSharedPreferenceChangeListener(sessionListener)
        if (pendingWipe) { pendingWipe = false; wipeWithPassword() }   // pedido por voz: siempre exige PIN o huella
    }

    override fun onPause() {
        getSharedPreferences("jarvis", MODE_PRIVATE).unregisterOnSharedPreferenceChangeListener(sessionListener)
        Bubble.appVisible = false; Bubble.sync(this)                      // al salir de la app, la burbuja aparece
        super.onPause()
    }

    companion object { @Volatile var pendingWipe = false }

    override fun onRequestPermissionsResult(rc: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(rc, p, r); startJarvis()
    }

    override fun onBackPressed() { if (menu.visibility == android.view.View.VISIBLE) menu.close() else super.onBackPressed() }

    private fun action(i: Int) {
        when (i) {
            0 -> voiceDialog()
            1 -> commandDialog()
            2 -> colorDialog()
            3 -> startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            4 -> learnHub()
            5 -> apiDialog()
            6 -> wipeWithPassword()
            7 -> pickCloud.launch(null)
            8 -> unlockDialog()
            9 -> mindDialog()
            10 -> Toast.makeText(this, Bubble.toggle(this), Toast.LENGTH_LONG).show()
            11 -> iaDialog()
        }
    }

    /** Cerebro de IA propio: estado, interruptor de encendido automático, descarga y dónde se guarda (teléfono o tarjeta SD). */
    private fun iaDialog() {
        val d = resources.displayMetrics.density
        val l = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding((20 * d).toInt(), (12 * d).toInt(), (20 * d).toInt(), 0) }
        val info = TextView(this).apply { text = IA.status(this@MainActivity); textSize = 15f }
        val sw = Switch(this).apply {
            text = "Encendido automático (la IA se enciende sola cuando no sabe algo y se apaga cuando ya lo sabe)"
            isChecked = Prefs.iaOn(this@MainActivity)
            setOnCheckedChangeListener { _, on -> Prefs.setIaOn(this@MainActivity, on); if (!on) Thread { IA.unloadNow() }.start() }
            setPadding(0, (14 * d).toInt(), 0, 0)
        }
        l.addView(info); l.addView(sw)
        fun bg(job: () -> String) = Thread { val r = try { job() } catch (e: Exception) { "Algo salió mal." }; runOnUiThread { Toast.makeText(this, r, Toast.LENGTH_LONG).show() } }.start()
        AlertDialog.Builder(this).setTitle("Cerebro de IA").setView(l)
            .setPositiveButton("Descargar (Wi-Fi)") { _, _ -> bg { IA.startDownload(this, false) } }
            .setNeutralButton("Con datos móviles") { _, _ -> bg { IA.startDownload(this, true) } }
            .setNegativeButton("Mover SD / teléfono") { _, _ ->
                val toSd = !IA.lugar(this).contains("SD")
                bg { IA.relocate(this, toSd) }
            }.show()
    }

    /** Cerebro virtual: resumen de lo que guarda y búsqueda en datos, pensamientos y cálculos. */
    private fun mindDialog() {
        val l = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 20, 40, 0) }
        val info = TextView(this).apply { text = Mind.stats(this@MainActivity, brain.learnedCount()) }
        val e = EditText(this).apply { hint = "Buscar en el cerebro…" }
        l.addView(info); l.addView(e)
        fun show(title: String, lines: List<String>) = AlertDialog.Builder(this).setTitle(title)
            .setMessage(if (lines.isEmpty()) "Nada todavía." else lines.joinToString("\n\n")).setPositiveButton("Cerrar", null).show()
        AlertDialog.Builder(this).setTitle("Cerebro").setView(l)
            .setPositiveButton("Buscar") { _, _ ->
                val q = e.text.toString().trim()
                if (q.isNotEmpty()) show("Resultados", listOfNotNull(brain.recall(q)?.let { Net.sentences(it, 300) }) + Mind.search(this, q, 8))
            }
            .setNeutralButton("Pensamientos") { _, _ -> show("Últimos pensamientos", Mind.recentThoughts(this, 8)) }
            .setNegativeButton("Cálculos") { _, _ -> show("Últimos cálculos", Mind.recentCalcs(this, 10)) }.show()
    }

    private fun voiceDialog() {
        val svc = JarvisService.instance
        val vs = svc?.voices().orEmpty()
        if (vs.isEmpty()) { Toast.makeText(this, "Aún no hay voces de Google disponibles", Toast.LENGTH_SHORT).show(); return }
        val names = vs.map { it.name }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Voz").setItems(names) { _, i ->
            Prefs.setVoice(this, names[i]); svc?.applyVoice(); svc?.speak("Así sueno ahora.")
        }.setNeutralButton("Más grave/aguda") { _, _ ->
            val np = if (Prefs.pitch(this) >= 1.4f) 0.7f else Prefs.pitch(this) + 0.2f
            Prefs.setPitch(this, np); svc?.applyVoice(); svc?.speak("Probando tono.")
        }.show()
    }

    /** Barra de comandos: escribes lo mismo que dirías ("temporizador de 1 hora 20 minutos") y se ejecuta al momento. */
    private fun commandDialog() {
        val d = resources.displayMetrics.density
        val l = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding((20 * d).toInt(), (12 * d).toInt(), (20 * d).toInt(), 0) }
        val e = EditText(this).apply {
            hint = "Escribe un comando… (ej: alarma a las 6 y cuarto)"; setSingleLine(); textSize = 17f
            imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_SEND
        }
        val out = TextView(this).apply { textSize = 16f; setTextIsSelectable(true); setPadding(0, (10 * d).toInt(), 0, (6 * d).toInt()) }
        l.addView(e); l.addView(out)
        val dlg = AlertDialog.Builder(this).setTitle("Comando").setView(l)
            .setPositiveButton("Ejecutar", null)                       // se enlaza abajo para que NO cierre la barra
            .setNeutralButton("Crear atajo") { _, _ -> shortcutDialog() }
            .setNegativeButton("Cerrar", null).create()
        dlg.setOnShowListener {
            val send = {
                val t = e.text.toString().trim()
                if (t.isNotEmpty()) { out.text = "Ejecutando…"; e.setText(""); runTyped(t) { r -> out.text = r } }
            }
            dlg.getButton(AlertDialog.BUTTON_POSITIVE).apply { textSize = 18f; setOnClickListener { send() } }
            dlg.getButton(AlertDialog.BUTTON_NEUTRAL).textSize = 15f
            dlg.getButton(AlertDialog.BUTTON_NEGATIVE).textSize = 15f
            e.setOnEditorActionListener { _, _, _ -> send(); true }
            e.requestFocus()
            dlg.window?.setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
        }
        dlg.show()
    }

    /** Ejecuta un comando escrito igual que uno hablado (sin necesidad de decir "Hola Génesis") y muestra la respuesta. */
    private fun runTyped(text: String, done: (String) -> Unit) {
        val svc = JarvisService.instance
        Thread {
            val r = try { svc?.runText(text) ?: CommandEngine(this, brain).handle(text) } catch (e: Exception) { "Algo salió mal con ese comando." }
            runOnUiThread { done(r); Hud.heard(text); svc?.speak(r) ?: Hud.say(r) }
        }.start()
    }

    /** Atajo propio: "cuando diga X, haz Y". */
    private fun shortcutDialog() {
        val l = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 20, 40, 0) }
        val a = EditText(this).apply { hint = "Cuando diga… (ej: modo trabajo)" }
        val c = EditText(this).apply { hint = "Haz… (ej: abre calendario)" }
        l.addView(a); l.addView(c)
        AlertDialog.Builder(this).setTitle("Nuevo atajo").setView(l).setPositiveButton("Guardar") { _, _ ->
            if (a.text.isNotBlank() && c.text.isNotBlank()) {
                brain.addCommand(a.text.toString(), c.text.toString())
                Toast.makeText(this, "Atajo guardado", Toast.LENGTH_SHORT).show()
            }
        }.show()
    }

    private fun colorDialog() {
        val cols = linkedMapOf("Cian" to "#00E5FF", "Azul" to "#2979FF", "Rojo" to "#FF1744", "Verde" to "#00E676",
            "Dorado" to "#FFC400", "Violeta" to "#D500F9", "Blanco" to "#FFFFFF")
        AlertDialog.Builder(this).setTitle("Color").setItems(cols.keys.toTypedArray()) { _, i ->
            Prefs.setColor(this, Color.parseColor(cols.values.elementAt(i))); hud.color = Prefs.color(this)
        }.show()
    }

    /** Botón Aprender: al tocarlo arranca solo el aprendizaje automático masivo y muestra el avance. */
    private fun learnHub() {
        if (!Prefs.turboOn(this)) {
            Turbo.start(this)
            Toast.makeText(this, "Aprendiendo de todo en automático", Toast.LENGTH_LONG).show()
            JarvisService.instance?.speak("Voy a aprender de todo en automático.")
        }
        showLearnStatus()
    }

    private fun showLearnStatus() {
        val on = Prefs.turboOn(this); val wifi = Prefs.turboWifi(this)
        val msg = "Aprendizaje automático: " + (if (on) "ACTIVO" else "apagado") +
            "\nArtículos leídos: ${Prefs.turboArticles(this)}" +
            "\n" + Mind.stats(this, brain.learnedCount()) +
            "\nDiccionario: ${Vocab.count(this)} palabras" +
            "\nRed: " + (if (wifi) "solo Wi-Fi (no gasta tus datos)" else "Wi-Fi y datos móviles") +
            "\n\nAprende en segundo plano aunque cierres la app, con batería suficiente y espacio libre."
        AlertDialog.Builder(this).setTitle("Aprender").setMessage(msg)
            .setPositiveButton(if (on) "Detener" else "Empezar") { _, _ ->
                if (on) { Turbo.stop(this); Toast.makeText(this, "Aprendizaje detenido", Toast.LENGTH_SHORT).show() } else Turbo.start(this)
            }
            .setNegativeButton("Escribir tema") { _, _ -> learnDialog() }
            .setNeutralButton(if (wifi) "Usar también datos" else "Solo Wi-Fi") { _, _ ->
                Turbo.setWifiOnly(this, !wifi); showLearnStatus()
            }.show()
    }

    /** Aprender: escribe cualquier palabra o tema (o varios separados por coma), o pega un enlace a un texto libre. */
    private fun learnDialog() {
        val l = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 20, 40, 0) }
        val e = EditText(this).apply {
            hint = "Una palabra, un tema o varios separados por coma. Ej: comida, recetas de pollo, Wikipedia, https://…"
            minLines = 2
        }
        val dict = if (Prefs.vocabDone(this)) "completo" else if (Prefs.vocabOn(this)) "aprendiendo en segundo plano" else "apagado"
        val info = TextView(this).apply { text = "\nDiccionario: ${Vocab.count(this@MainActivity)} palabras ($dict)" }
        l.addView(e); l.addView(info)
        AlertDialog.Builder(this).setTitle("Aprender").setView(l)
            .setPositiveButton("Aprender") { _, _ ->
                val t = e.text.toString().trim()
                if (t.isNotEmpty()) {
                    Toast.makeText(this, "Aprendiendo…", Toast.LENGTH_SHORT).show()
                    Thread {
                        val n = if (t.startsWith("http")) brain.learnFromUrl(t, "lectura") else Learner.many(this, brain, t)
                        runOnUiThread {
                            val msg = if (n > 0) "Aprendí $n cosas nuevas." else "No aprendí nada nuevo. ¿Hay internet?"
                            Toast.makeText(this, msg, Toast.LENGTH_LONG).show(); JarvisService.instance?.speak(msg)
                        }
                    }.start()
                }
            }
            .setNeutralButton(if (Prefs.vocabOn(this)) "Parar diccionario" else "Diccionario completo") { _, _ ->
                if (Prefs.vocabOn(this)) { Vocab.stop(this); Toast.makeText(this, "Diccionario en pausa.", Toast.LENGTH_SHORT).show() }
                else { Vocab.start(this); Toast.makeText(this, "Aprendiendo el diccionario en segundo plano (con internet y batería).", Toast.LENGTH_LONG).show() }
            }
            .setNegativeButton("Cancelar", null).show()
    }

    private fun apiDialog() {
        val e = EditText(this).apply {
            hint = "Clave de API de Anthropic (sk-ant-…)"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        AlertDialog.Builder(this).setTitle("IA con razonamiento profundo")
            .setMessage("Con internet y tu clave, Génesis razona con un modelo de lenguaje y guarda lo aprendido para usarlo sin internet. La clave se guarda solo en este celular.")
            .setView(e).setPositiveButton("Guardar") { _, _ ->
                Prefs.setApiKey(this, e.text.toString().trim().ifEmpty { null })
            }.setNeutralButton("Quitar clave") { _, _ -> Prefs.setApiKey(this, null) }.show()
    }

    /** Pide el PIN / patrón / contraseña o la huella del propio celular antes de una acción sensible. */
    private fun confirmOwner(title: String, onOk: () -> Unit) {
        val auth = BiometricManager.Authenticators.BIOMETRIC_WEAK or BiometricManager.Authenticators.DEVICE_CREDENTIAL
        if (BiometricManager.from(this).canAuthenticate(auth) != BiometricManager.BIOMETRIC_SUCCESS) {
            Toast.makeText(this, "Configura primero un bloqueo de pantalla (PIN, patrón o huella)", Toast.LENGTH_LONG).show(); return
        }
        val info = BiometricPrompt.PromptInfo.Builder().setTitle(title)
            .setSubtitle("Confirma con tu PIN o tu huella").setAllowedAuthenticators(auth).build()
        BiometricPrompt(this, ContextCompat.getMainExecutor(this), object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(r: BiometricPrompt.AuthenticationResult) { onOk() }
        }).authenticate(info)
    }

    /** Borra la memoria solo tras validar PIN / patrón / contraseña o huella. */
    private fun wipeWithPassword() = confirmOwner("Borrar memoria de Génesis") {
        brain.wipe(); JarvisService.instance?.speak("Memoria borrada.")
    }

    /** Guardar o quitar el PIN para "desbloquea" por voz (también exige PIN o huella). */
    /** Desbloqueo por voz: primero se elige si guardar el PIN o el patrón (los dos pueden estar guardados). */
    private fun unlockDialog() = confirmOwner("Desbloqueo por voz") {
        val pinOn = if (PinVault.has(this)) " (guardado)" else ""
        val patOn = if (PinVault.hasPattern(this)) " (guardado)" else ""
        AlertDialog.Builder(this).setTitle("Desbloquear con la voz")
            .setItems(arrayOf("PIN del celular$pinOn", "Patrón de desbloqueo$patOn")) { _, i -> if (i == 0) pinDialog() else patternDialog() }
            .setNegativeButton("Cancelar", null).show()
    }

    /** Dibujar y guardar el patrón (cifrado en el celular). Lo usa para el celular y para las apps con bloqueo de patrón. */
    private fun patternDialog() {
        val d = resources.displayMetrics.density
        val l = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 20, 40, 0); gravity = Gravity.CENTER_HORIZONTAL }
        val info = TextView(this).apply { text = "Dibuja tu patrón de desbloqueo (mínimo 4 puntos), igual que lo haces en el celular." }
        val pad = PatternPad(this)
        l.addView(info)
        l.addView(pad, LinearLayout.LayoutParams((240 * d).toInt(), (240 * d).toInt()))
        AlertDialog.Builder(this).setTitle("Patrón").setView(l)
            .setPositiveButton("Guardar") { _, _ ->
                if (pad.seq.size >= 4) { PinVault.savePattern(this, pad.seq.joinToString("")); Toast.makeText(this, "Patrón guardado", Toast.LENGTH_SHORT).show() }
                else Toast.makeText(this, "Dibuja al menos 4 puntos", Toast.LENGTH_SHORT).show()
            }
            .setNeutralButton("Quitar patrón") { _, _ -> PinVault.savePattern(this, null); Toast.makeText(this, "Patrón eliminado", Toast.LENGTH_SHORT).show() }
            .setNegativeButton("Cancelar", null).show()
    }

    private fun pinDialog() {
        val e = EditText(this).apply {
            hint = if (PinVault.has(this@MainActivity)) "Ya hay un PIN guardado (escribe otro para cambiarlo)" else "Tu PIN del celular (solo números)"
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        }
        AlertDialog.Builder(this).setTitle("Desbloquear con la voz")
            .setMessage("Génesis desliza la pantalla y escribe tu PIN por Accesibilidad. Se guarda cifrado en este celular, pero cualquiera que diga \"Hola Génesis, desbloquea\" podrá abrirlo. Para un patrón, elige \"Patrón de desbloqueo\" en el paso anterior. La huella no se puede poner.")
            .setView(e)
            .setPositiveButton("Guardar") { _, _ ->
                val v = e.text.toString().filter { it.isDigit() }
                if (v.length >= 4) { PinVault.save(this, v); Toast.makeText(this, "PIN guardado", Toast.LENGTH_SHORT).show() }
                else Toast.makeText(this, "Escribe al menos 4 números", Toast.LENGTH_SHORT).show()
            }
            .setNeutralButton("Quitar PIN") { _, _ -> PinVault.save(this, null); Toast.makeText(this, "PIN eliminado", Toast.LENGTH_SHORT).show() }
            .setNegativeButton("Cancelar", null).show()
    }
}
