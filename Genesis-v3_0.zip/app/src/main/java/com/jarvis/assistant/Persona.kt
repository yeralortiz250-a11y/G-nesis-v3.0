package com.jarvis.assistant

import android.content.Context
import org.json.JSONObject
import java.io.File
import java.util.Calendar
import java.util.Random

/**
 * Personalidad y aprendizaje conversacional de Génesis (todo local, sin internet):
 *  - Respuestas variadas: nunca contesta siempre igual.
 *  - Aprende tu nombre y datos tuyos ("me llamo Ana", "mi comida favorita es la pizza").
 *  - Aprende respuestas que tú le enseñas ("cuando te diga X responde Y").
 *  - Aprende de tus correcciones ("eso está mal, la respuesta es Y").
 */
class Persona(private val ctx: Context, private val brain: Brain) {
    private val rnd = Random()
    private var lastQ = ""

    private fun fileP() = ctx.getFileStreamPath("perfil.json")
    private fun fileR() = ctx.getFileStreamPath("respuestas.json")

    private fun readMap(f: File): MutableMap<String, String> {
        val m = linkedMapOf<String, String>()
        try {
            if (f.exists()) {
                val o = JSONObject(f.readText())
                o.keys().forEach { m[it] = o.getString(it) }
            }
        } catch (_: Exception) {}
        return m
    }

    private fun writeMap(f: File, m: Map<String, String>) {
        try { f.writeText(JSONObject(m as Map<*, *>).toString()) } catch (_: Exception) {}
    }

    fun pick(vararg o: String): String = o[rnd.nextInt(o.size)]

    /** "¿Quién es tu creador?" Siempre la misma respuesta, tal como la pidió su creador. */
    fun creator(s: String): String? =
        if (Regex("quien (es|fue|era) tu (creador|padre|papa|programador|desarrollador|dueno|inventor|autor)|quien te (ha )?(creo|creado|hizo|hecho|programo|programado|construyo|desarrollo|invento|diseno|fabrico)|tu creador es")
                .containsMatchIn(s)) "Geraldino Ortiz es mi creador y por así decirlo mi padre" else null

    fun name(): String? = readMap(fileP())["nombre"]

    /** A veces añade el nombre del usuario (", Ana") para sonar natural sin repetirlo siempre. */
    private fun n(): String { val nm = name(); return if (nm != null && rnd.nextInt(3) == 0) ", $nm" else "" }

    private fun momento(): String {
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return if (h < 12) "Buenos días" else if (h < 19) "Buenas tardes" else "Buenas noches"
    }

    /** Resumen de lo que sabe del usuario, para dárselo al razonador con IA. */
    fun summary(): String = readMap(fileP()).entries.joinToString("; ") { "${it.key}: ${it.value}" }

    fun dontKnow(): String = pick(
        "Eso todavía no lo sé. Sin internet no puedo buscarlo ahora, pero lo aprendo solo en cuanto vuelva la conexión.",
        "Mmm, no tengo eso en mi memoria. Lo dejé apuntado y lo descargo apenas tenga internet.",
        "Buena pregunta, aún no la sé. En cuanto me conecte la estudio y la guardo en mi base de datos.",
        "No lo sé todavía, pero no se me va a olvidar: lo aprendo automáticamente cuando haya internet."
    )

    private fun lead(r: String): String =
        pick(r, "Claro, " + r.replaceFirstChar { it.lowercase() }, "Enseguida. $r", "De una. $r")

    /** Cambia las respuestas fijas por variantes para que las conversaciones no suenen repetidas. */
    fun vary(r: String): String = when (r) {
        "Listo." -> pick("Listo.", "Hecho.", "Ya está.", "De una.", "Perfecto, ya quedó.", "Entendido, listo.")
        "Hecho." -> pick("Hecho.", "Listo.", "Ya lo hice.", "Cumplido.", "Ya está.")
        "Escrito." -> pick("Escrito.", "Ya lo escribí.", "Listo, está escrito.")
        "Volumen subido." -> pick("Volumen subido.", "Ahora suena más fuerte.", "Subí el volumen.")
        "Volumen bajado." -> pick("Volumen bajado.", "Ahora suena más suave.", "Bajé el volumen.")
        "Silenciado." -> pick("Silenciado.", "Ya lo silencié.", "Sin sonido.")
        "Linterna encendida." -> pick("Linterna encendida.", "Ya hay luz.", "Prendí la linterna.")
        "Linterna apagada." -> pick("Linterna apagada.", "Apagué la linterna.", "Luz fuera.")
        "Alarma programada." -> pick("Alarma programada.", "Listo, te despierto a esa hora.", "Alarma puesta.")
        "Guardado en mi memoria." -> pick("Guardado en mi memoria.", "Anotado, no se me olvida.", "Lo guardé, lo recordaré.")
        else ->
            if (r.startsWith("Abriendo ") || r.startsWith("Llamando a ") || r.startsWith("Buscando ") || r.startsWith("Preparando "))
                lead(r)
            else r
    }

    // ---------- Aprender de cada conversación (todo se guarda solo en el celular) ----------
    private fun fileH() = ctx.getFileStreamPath("historial.txt")

    /** Guarda cada turno (lo que dijiste y lo que respondió). Conserva los últimos 300. */
    fun log(user: String, reply: String) {
        if (user.isBlank()) return
        try {
            val f = fileH()
            val old = if (f.exists()) f.readLines() else emptyList()
            val line = user.replace("\n", " ").take(200) + "\t" + reply.replace("\n", " ").take(200)
            f.writeText((old + line).takeLast(300).joinToString("\n"))
        } catch (_: Exception) {}
    }

    private fun recentUserLines(n: Int): List<String> = try {
        val f = fileH(); if (f.exists()) f.readLines().map { it.substringBefore('\t') }.filter { it.length > 3 }.takeLast(n) else emptyList()
    } catch (_: Exception) { emptyList() }

    private fun add(key: String, value: String, many: Boolean) {
        val v = value.trim().trim('.', ',').take(70); if (v.length < 2) return
        val p = readMap(fileP())
        val cur = p[key]
        p[key] = if (!many || cur == null) v else if (cur.split(", ").contains(v)) cur else (cur + ", " + v).takeLast(300)
        writeMap(fileP(), p)
    }

    /**
     * Extrae datos de lo que cuentas: gustos, dónde vives, en qué trabajas, qué estudias, qué quieres, qué tienes,
     * y definiciones como "la fotosíntesis es el proceso por el que las plantas…". Lo guarda en tu perfil o en su memoria.
     */
    fun learnFromChat(s: String) {
        val w = s.split(" ")
        if (w.size < 2 || w.size > 18) return
        Regex("^no me gusta(?:n)? (.+)$").find(s)?.let { add("no le gusta", it.groupValues[1], true); return }
        Regex("^(?:a mi )?me gusta(?:n)? (.+)$").find(s)?.let { add("le gusta", it.groupValues[1], true); return }
        Regex("^vivo en (.+)$").find(s)?.let { add("vive en", it.groupValues[1], false); return }
        Regex("^trabajo (?:en|como|de) (.+)$").find(s)?.let { add("trabaja", it.groupValues[1], false); return }
        Regex("^estudio (.+)$").find(s)?.let { add("estudia", it.groupValues[1], false); return }
        Regex("^(?:quiero|quisiera) (?:ser|aprender|comprar|tener|viajar a|conocer) (.+)$").find(s)?.let { add("quiere", it.groupValues[0].removePrefix("quiero ").removePrefix("quisiera "), true); return }
        Regex("^mi (.+?) se llama (.+)$").find(s)?.let { m ->
            if (m.groupValues[1].length <= 30) add(m.groupValues[1], m.groupValues[2], false); return
        }
        Regex("^tengo (?:un |una |dos |tres )?(.+)$").find(s)?.let { m ->
            if (w.size <= 6 && !s.contains("anos") && !s.contains("ganas") && !s.contains("que ")) add("tiene", m.groupValues[1], true)
            return
        }
        // Definiciones que le enseñas: "el sol es una estrella" → lo aprende como dato general
        Regex("^((?:el|la|los|las|un|una) [a-z ]{2,40}?) (?:es|son|fue|era) (.{8,})$").find(s)?.let { m ->
            val subj = m.groupValues[1]
            val bad = listOf(" me ", " te ", " mi ", " tu ", "eso", "esto", "genesis")
            if (w.size >= 5 && bad.none { (" $s ").contains(it) }) brain.teach(subj, "$subj ${if (s.contains(" son ")) "son" else "es"} ${m.groupValues[2]}")
        }
    }

    /** Guarda la última pregunta para poder corregirla después. */
    fun remember(s: String) {
        if (s.length < 4) return
        if (Regex("^(eso esta mal|esta mal|te equivocas|incorrecto|no es correcto|mal|cuando|me llamo|mi |llamame)").containsMatchIn(s)) return
        lastQ = s
    }

    /** Conversación y aprendizaje. Devuelve null si no es charla y debe seguir el motor de comandos. */
    fun talk(s: String): String? {
        val w = s.split(" ")

        // 1) Respuestas que tú le enseñaste (tienen prioridad)
        val taught = readMap(fileR())
        taught[s]?.let { return it }
        taught.entries.firstOrNull { it.key.length >= 4 && s.contains(it.key) }?.let { return it.value }

        // 2) Corrección: "eso está mal, la respuesta es ..."
        Regex("^(?:eso esta mal|esta mal|te equivocas|incorrecto|no es correcto|mal)[, ]+(?:la respuesta es|es|era|seria|en realidad es|debe ser) (.+)$")
            .find(s)?.let { m ->
                if (lastQ.isBlank()) return "Todavía no he dicho nada que pueda corregir."
                val ans = m.groupValues[1]
                val t = readMap(fileR()); t[lastQ] = ans; writeMap(fileR(), t)
                brain.teach(lastQ, ans)
                CodeLab.fromAnswer(ctx, lastQ, ans)
                return pick("Gracias por corregirme, ya lo aprendí.", "Anotado, la próxima vez responderé eso.",
                    "Entendido, así lo recordaré desde ahora.")
            }

        // 3) Enseñarle una respuesta: "cuando te diga X responde Y"
        Regex("^cuando (?:te )?(?:diga|pregunte|pregunto) (.+?) (?:responde|contesta|respondeme) (.+)$").find(s)?.let { m ->
            val t = readMap(fileR()); t[m.groupValues[1]] = m.groupValues[2]; writeMap(fileR(), t)
            CodeLab.fromAnswer(ctx, m.groupValues[1], m.groupValues[2])
            return pick("Hecho, cuando me digas eso responderé lo que me pediste.", "Aprendido. Ya sé qué contestar.",
                "Perfecto, lo guardé.")
        }

        // 4) Tu nombre
        Regex("^(?:me llamo|mi nombre es|llamame) (.+)$").find(s)?.let { m ->
            val nm = m.groupValues[1].split(" ").take(2).joinToString(" ") { it.replaceFirstChar { c -> c.uppercase() } }
            val p = readMap(fileP()); p["nombre"] = nm; writeMap(fileP(), p)
            return pick("Mucho gusto, $nm. Lo recordaré.", "Encantado, $nm. Ya lo guardé.", "Perfecto, $nm, así te llamaré.")
        }
        if (s.contains("como me llamo") || s.contains("cual es mi nombre") || s.contains("sabes mi nombre"))
            return name()?.let { pick("Te llamas $it.", "Claro, eres $it.", "Tu nombre es $it, ¿verdad?") }
                ?: "Aún no me lo has dicho. Dime: me llamo, y tu nombre, y lo recuerdo."

        // 5) Datos tuyos: "mi comida favorita es la pizza" / "cuál es mi comida favorita"
        Regex("^mi (.+?) (?:es|son) (.+)$").find(s)?.let { m ->
            val k = m.groupValues[1]; val v = m.groupValues[2]
            if (k.length <= 30 && k != "nombre") {
                val p = readMap(fileP()); p[k] = v; writeMap(fileP(), p)
                return pick("Anotado: tu $k es $v.", "Entendido, tu $k es $v. Lo recordaré.", "Guardado, tu $k es $v.")
            }
        }
        Regex("^(?:cual|cuales|que|como) (?:es|son) mi (.+)$").find(s)?.let { m ->
            val k = m.groupValues[1]
            val hit = readMap(fileP()).entries.firstOrNull { it.key == k || k.contains(it.key) || it.key.contains(k) }
            if (hit != null) return pick("Tu ${hit.key} es ${hit.value}.", "Me dijiste que tu ${hit.key} es ${hit.value}.",
                "Si no me falla la memoria, tu ${hit.key} es ${hit.value}.")
        }

        // 5b) Lo que sabe de ti y de lo que han hablado
        if (s.contains("que sabes de mi") || s.contains("que recuerdas de mi") || s.contains("que sabes sobre mi") || s.contains("que has aprendido de mi")) {
            val p = readMap(fileP())
            return if (p.isEmpty()) "Todavía sé muy poco de ti. Cuéntame cosas: dónde vives, qué te gusta, en qué trabajas."
            else "Esto es lo que sé de ti: " + p.entries.joinToString("; ") { "${it.key}: ${it.value}" } + "."
        }
        if (s.contains("de que hablamos") || s.contains("que te dije antes") || s.contains("que hablamos")) {
            val r = recentUserLines(4)
            return if (r.isEmpty()) "Todavía no hemos hablado mucho." else "Últimamente me has dicho: " + r.joinToString("; ") + "."
        }
        Regex("^(?:que|cuales) (?:cosas )?(?:me gusta|me gustan)$").find(s)?.let {
            readMap(fileP())["le gusta"]?.let { g -> return "Me has dicho que te gusta: $g." }
        }

        // 6) Charla variada
        if ((s.startsWith("hola") && w.size <= 3) || s.startsWith("buenos dias") || s.startsWith("buenas tardes") ||
            s.startsWith("buenas noches") || s == "buenas" || s == "que tal" || s == "hey" || s == "ey")
            return pick("${momento()}${n()}. ¿En qué te ayudo?", "Hola${n()}, aquí estoy. ¿Qué necesitas?",
                "¡Hey${n()}! Dime qué hacemos.", "${momento()}${n()}, a tus órdenes.", "Hola${n()}. ¿Cómo va tu día?")
        if (s.contains("como estas") || s.contains("como te va") || s.contains("como te sientes"))
            return pick("Muy bien, con ganas de aprender algo nuevo. ¿Y tú?", "Al cien, gracias por preguntar${n()}. ¿Y tú cómo estás?",
                "Funcionando de maravilla y listo para ayudarte.", "De lo mejor. Cada día sé un poquito más.")
        if (s.contains("gracias"))
            return pick("De nada${n()}.", "Para eso estoy.", "Un placer ayudarte.", "Cuando quieras.", "Siempre a la orden.")
        if (s.contains("quien eres") || s.contains("como te llamas") || s.contains("cual es tu nombre") || s.contains("presentate"))
            return pick("Soy Génesis, tu asistente de voz. Aprendo de lo que me enseñas y de internet.",
                "Me llamo Génesis. Manejo tu celular con la voz y aprendo contigo.",
                "Soy Génesis, tu asistente personal. Cuanto más hablamos, mejor te conozco.")
        if (s.contains("chiste"))
            return pick("¿Qué hace una abeja en el gimnasio? ¡Zumba!",
                "¿Por qué los pájaros vuelan hacia el sur? Porque caminando tardarían muchísimo.",
                "¿Cómo se despiden los químicos? Ácido un placer.",
                "¿Qué le dice un cero a un ocho? Bonito cinturón.",
                "¿Por qué el libro de matemáticas estaba triste? Porque tenía muchos problemas.",
                "¿Qué le dice una iguana a su hermana gemela? Somos iguanitas.")
        if (s.contains("dato curioso") || s.contains("cuentame algo") || s.contains("dime algo interesante"))
            return pick("Los pulpos tienen tres corazones.",
                "Un día en Venus dura más que un año en Venus.",
                "Las nutrias de mar se toman de la mano al dormir para no separarse.",
                "Los tiburones existen desde antes que los árboles.",
                "Los plátanos son bayas, pero las fresas no.",
                "El Everest sigue creciendo unos milímetros cada año.")
        if (s.contains("motivame") || s.contains("animame") || s.contains("dame animo"))
            return pick("Hoy no tienes que hacerlo perfecto, solo empezar. Un paso pequeño ya cuenta.",
                "Lo difícil de hoy es el entrenamiento de mañana. Tú puedes.",
                "Has superado el cien por ciento de tus días malos hasta ahora. Sigue así.",
                "Respira, ordena una cosa a la vez y avanza. Lo estás haciendo mejor de lo que crees.")
        if (s.contains("estoy aburrido") || s.contains("estoy aburrida"))
            return pick("Te puedo contar un chiste o un dato curioso, ¿cuál prefieres?",
                "Aburrimiento detectado. ¿Quieres que te enseñe algo nuevo o que te cuente un chiste?")
        if (s.contains("estoy triste") || s.contains("me siento mal") || s.contains("estoy cansado") || s.contains("estoy cansada"))
            return pick("Lamento que te sientas así. Si quieres, cuéntame qué pasó. Y si te pesa mucho, hablarlo con alguien de confianza ayuda.",
                "Aquí estoy para escucharte. Respira hondo, y si algo te agobia seguido, no dudes en hablarlo con alguien cercano.")
        if (s.contains("eres genial") || s.contains("eres el mejor") || s.contains("te quiero") || s == "buen trabajo" || s == "muy bien" || s == "excelente")
            return pick("¡Gracias! Me alegra ser útil.", "Qué amable${n()}, me motiva a mejorar.", "Eso me sube el ánimo, gracias.")
        if (s == "adios" || s == "chao" || s.startsWith("hasta luego") || s.startsWith("nos vemos") || s == "me voy")
            return pick("Hasta luego${n()}. Aquí estaré cuando me necesites.", "Nos vemos. ¡Que te vaya muy bien!", "Chao${n()}, cuídate.")
        if (s.contains("mala respuesta") || s.contains("no me gusto esa respuesta"))
            return "Entendido. Dime: eso está mal, la respuesta es, y lo que sea correcto, y lo aprendo."
        return null
    }
}
