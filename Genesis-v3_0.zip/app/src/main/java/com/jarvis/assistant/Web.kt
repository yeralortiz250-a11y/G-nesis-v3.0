package com.jarvis.assistant

import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL

/**
 * Acceso abierto a internet: cualquier sitio http o https, siguiendo redirecciones (incluso de http a https),
 * con identificación de navegador móvil, gzip automático, detección de codificación y tope de tamaño.
 */
object Web {
    const val UA = "Mozilla/5.0 (Linux; Android 14; Genesis) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36"

    /** Devuelve el cuerpo de la respuesta si el servidor contesta 200; si no, null. */
    fun fetch(url: String, ms: Int = 8000, ua: String = UA, maxBytes: Int = 2_000_000): String? {
        var u = url
        try {
            for (hop in 0 until 7) {
                val c = URL(u).openConnection() as HttpURLConnection
                c.instanceFollowRedirects = false
                c.connectTimeout = ms; c.readTimeout = ms
                c.setRequestProperty("User-Agent", ua)
                c.setRequestProperty("Accept", "text/html,application/json,text/plain,*/*;q=0.8")
                c.setRequestProperty("Accept-Language", "es,en;q=0.7")
                val code = c.responseCode
                if (code in 301..308) {
                    val loc = c.getHeaderField("Location") ?: return null
                    u = URL(URL(u), loc).toString()
                    c.disconnect()
                    continue
                }
                if (code != 200) { c.disconnect(); return null }
                val cs = Regex("charset=([\\w-]+)", RegexOption.IGNORE_CASE).find(c.contentType ?: "")?.groupValues?.get(1)
                val buf = ByteArrayOutputStream()
                c.inputStream.use { ins ->
                    val b = ByteArray(8192)
                    while (buf.size() < maxBytes) { val n = ins.read(b); if (n < 0) break; buf.write(b, 0, n) }
                }
                c.disconnect()
                return String(buf.toByteArray(), try { charset(cs ?: "UTF-8") } catch (_: Exception) { Charsets.UTF_8 })
            }
        } catch (_: Exception) {}
        return null
    }

    /** Convierte HTML en texto legible (sin scripts, estilos ni etiquetas). */
    fun text(html: String): String {
        var t = html
        t = t.replace(Regex("(?is)<(script|style|noscript|svg|head)[^>]*>.*?</\\1>"), " ")
        t = t.replace(Regex("(?s)<!--.*?-->"), " ")
        t = t.replace(Regex("(?i)</?(p|div|br|li|h[1-6]|tr|section|article)[^>]*>"), ". ")
        t = t.replace(Regex("<[^>]+>"), " ")
        t = t.replace("&nbsp;", " ").replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">")
            .replace("&quot;", "\"").replace("&#39;", "'").replace("&aacute;", "á").replace("&eacute;", "é")
            .replace("&iacute;", "í").replace("&oacute;", "ó").replace("&uacute;", "ú").replace("&ntilde;", "ñ")
        t = t.replace(Regex("\\s+"), " ").replace(Regex("(\\. ){2,}"), ". ").trim()
        return t
    }
}
