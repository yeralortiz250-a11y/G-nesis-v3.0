package com.jarvis.assistant

import android.content.Context
import android.net.Uri
import android.os.StatFs
import android.provider.DocumentsContract
import org.json.JSONArray
import org.json.JSONObject

/**
 * Memoria "sin tope": cuando el celular se está llenando (poco espacio libre o demasiados datos locales),
 * Jarvis archiva el 70% más antiguo de lo aprendido en una carpeta de tu nube (Google Drive, OneDrive, Dropbox...)
 * que tú eliges desde el menú > Nube. Localmente solo deja un índice liviano de temas.
 * Cuando una pregunta no se responde con la memoria local y hay internet, busca en el archivo de la nube.
 * No usa claves ni APIs: usa el selector de carpetas de Android.
 */
object CloudArchive {
    private const val MAX_LOCAL = 20000                 // datos aprendidos en el celular antes de archivar
    private const val LOW_FREE = 1_000_000_000L         // < 1 GB libre → archivar
    private const val CRITICAL_FREE = 300_000_000L      // < 300 MB libre → dejar de aprender para proteger el celular

    fun tree(c: Context): Uri? = Prefs.tree(c)?.let { Uri.parse(it) }

    private fun stat(c: Context) = StatFs(c.filesDir.path)
    private fun free(c: Context) = stat(c).availableBytes

    fun needsArchive(c: Context, b: Brain): Boolean {
        val s = stat(c)
        return b.learnedCount() > MAX_LOCAL || s.availableBytes < LOW_FREE ||
            s.availableBytes.toDouble() / s.totalBytes < 0.10
    }

    fun critical(c: Context) = free(c) < CRITICAL_FREE

    /** Sube el 70% más antiguo a la nube y lo quita del celular. Devuelve true si lo logró. */
    fun archive(c: Context, b: Brain): Boolean {
        val t = tree(c) ?: return false
        val all = b.learnedSnapshot()
        if (all.size < 50) return false
        val n = (all.size * 0.7).toInt()
        val chunk = all.take(n)
        return try {
            val parent = DocumentsContract.buildDocumentUriUsingTree(t, DocumentsContract.getTreeDocumentId(t))
            val doc = DocumentsContract.createDocument(c.contentResolver, parent, "application/json",
                "jarvis_memoria_${System.currentTimeMillis()}.json") ?: return false
            val arr = JSONArray()
            chunk.forEach { arr.put(JSONObject().put("t", it.first).put("x", it.second)) }
            c.contentResolver.openOutputStream(doc, "w")!!.use { it.write(arr.toString().toByteArray()) }
            // Solo borra del celular si la escritura en la nube salió bien
            val idx = readIndex(c)
            chunk.map { it.first }.distinct().forEach { idx.put(JSONObject().put("t", it).put("u", doc.toString())) }
            c.getFileStreamPath("cloud_index.json").writeText(idx.toString())
            b.dropOldestLearned(n)
            true
        } catch (_: Exception) { false }
    }

    /** Busca en los archivos de la nube lo que ya no está en el celular. */
    fun recallFromCloud(c: Context, q: String): String? {
        if (tree(c) == null) return null
        val idx = readIndex(c); if (idx.length() == 0) return null
        val qw = Brain.tokens(q); if (qw.isEmpty()) return null
        var bestUri: String? = null; var bestScore = 0
        for (i in 0 until idx.length()) {
            val o = idx.getJSONObject(i)
            val sc = qw.count { it in Brain.tokens(o.getString("t")) }
            if (sc > bestScore) { bestScore = sc; bestUri = o.getString("u") }
        }
        val uri = bestUri ?: return null
        return try {
            val txt = c.contentResolver.openInputStream(Uri.parse(uri))!!.bufferedReader().use { it.readText() }
            val a = JSONArray(txt)
            val list = (0 until a.length()).map { a.getJSONObject(it).let { o -> o.getString("t") to o.getString("x") } }
            Brain.bestMatch(list, q)
        } catch (_: Exception) { null }
    }

    private fun readIndex(c: Context): JSONArray = try {
        JSONArray(c.getFileStreamPath("cloud_index.json").readText())
    } catch (_: Exception) { JSONArray() }
}
